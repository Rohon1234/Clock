# Clock (iPhone-style) for Android 13 to 16

Kotlin + Jetpack Compose clock app, `minSdk = 33` (Android 13) and `targetSdk = 35`; it runs on Android 13, 14, 15 and 16.

## Features
- **World Clock** – add/remove cities, day label and hour offset like iOS
- **Alarm** – time picker, repeat days, label, on/off switch; rings with the system alarm sound until dismissed, survives reboot
- **Stopwatch** – start/stop, laps, centisecond display
- **Timer** – iOS-style snapping wheels, progress ring, pause/resume, rings when finished (even if the app is closed)
- **Widgets** – *Digital Clock* (2x1) and *Analog Clock* with second hand (2x2); tap opens the app

## Build
1. Open the `IOSClock` folder in **Android Studio** (Ladybug or newer) and let Gradle sync.
2. Run on a device with Android 13 to 16, or on an emulator with API 33 or newer.
3. Long-press the home screen → Widgets → Clock to add the widgets.

On first launch, allow notifications so alarms and timers can ring.
