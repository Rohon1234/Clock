# Clock (iPhone-style) for Android 15

Kotlin + Jetpack Compose clock app, `minSdk = targetSdk = 35` (Android 15 only).

## Features
- **World Clock** – add/remove cities, day label and hour offset like iOS
- **Alarm** – time picker, repeat days, label, on/off switch; rings with the system alarm sound until dismissed, survives reboot
- **Stopwatch** – start/stop, laps, centisecond display
- **Timer** – iOS-style snapping wheels, progress ring, pause/resume, rings when finished (even if the app is closed)
- **Widgets** – *Digital Clock* (2x1) and *Analog Clock* with second hand (2x2); tap opens the app

## Build
1. Open the `IOSClock` folder in **Android Studio** (Ladybug or newer) and let Gradle sync.
2. Run on an Android 15 device or an API 35 emulator.
3. Long-press the home screen → Widgets → Clock to add the widgets.

On first launch, allow notifications so alarms and timers can ring.
