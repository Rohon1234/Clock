package com.example.iosclock.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.iosclock.MainActivity
import com.example.iosclock.R
import java.time.ZoneId

/**
 * Rounded-square clock widgets with a 60-tick seconds ring, date on top and temperature below.
 *
 * Time and date are TextClocks, so the host ticks them without our process. The seconds tail is a
 * ViewFlipper of 60 pre-drawn frames that flips once per second by itself; an alarm re-aligns it to
 * the real second at every minute boundary (and straight after the phone wakes up).
 */
object SecondsWidgets {
    private const val ACTION_SYNC = "com.example.iosclock.SECONDS_SYNC"
    private const val PREFS = "clock_prefs"

    private val providers: List<Pair<Class<*>, Int>> = listOf(
        SecondsBlackWidget::class.java to R.layout.widget_seconds_black,
        SecondsWhiteWidget::class.java to R.layout.widget_seconds_white,
    )

    fun zoneOf(ctx: Context, id: Int): String {
        val saved = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("wz_$id", null)
        return try {
            if (saved != null) ZoneId.of(saved).id else ZoneId.systemDefault().id
        } catch (e: Exception) {
            ZoneId.systemDefault().id
        }
    }

    fun setZone(ctx: Context, id: Int, zone: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("wz_$id", zone).apply()
    }

    fun forget(ctx: Context, ids: IntArray) {
        val e = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        ids.forEach { e.remove("wz_$it") }
        e.apply()
    }

    fun activeZones(ctx: Context): Set<String> {
        val mgr = AppWidgetManager.getInstance(ctx)
        return providers
            .flatMap { (cls, _) -> mgr.getAppWidgetIds(ComponentName(ctx, cls)).toList() }
            .map { zoneOf(ctx, it) }
            .toSet()
    }

    fun hasWidgets(ctx: Context): Boolean {
        val mgr = AppWidgetManager.getInstance(ctx)
        return providers.any { (cls, _) -> mgr.getAppWidgetIds(ComponentName(ctx, cls)).isNotEmpty() }
    }

    fun updateAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val second = ((System.currentTimeMillis() / 1000) % 60).toInt()
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        for ((cls, layout) in providers) {
            for (id in mgr.getAppWidgetIds(ComponentName(ctx, cls))) {
                val zone = zoneOf(ctx, id)
                val wx = WeatherRepo.cached(ctx, zone)
                val views = RemoteViews(ctx.packageName, layout)
                views.setDisplayedChild(R.id.seconds_flipper, second)
                views.setString(R.id.time_clock, "setTimeZone", zone)
                views.setString(R.id.date_clock, "setTimeZone", zone)
                views.setTextViewText(R.id.temp_label, if (wx != null) "${wx.tempC}°" else "--°")
                views.setImageViewResource(R.id.weather_icon, wx?.icon ?: R.drawable.ic_wx_sun)
                views.setOnClickPendingIntent(R.id.widget_root, open)
                mgr.updateAppWidget(id, views)
            }
        }
    }

    private fun syncIntent(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 77,
            Intent(ctx, SecondsSyncReceiver::class.java).setAction(ACTION_SYNC),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    fun scheduleNext(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val next = (System.currentTimeMillis() / 60_000L + 1) * 60_000L
        // Non-waking: if the screen is off the alarm is delivered the moment the phone wakes up.
        try {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC, next, syncIntent(ctx))
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC, next, syncIntent(ctx))
        }
    }

    fun cancel(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(syncIntent(ctx))
    }

    fun refresh(ctx: Context) {
        if (hasWidgets(ctx)) {
            updateAll(ctx)
            scheduleNext(ctx)
        } else {
            cancel(ctx)
        }
    }
}

abstract class SecondsWidgetProvider : AppWidgetProvider() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending: BroadcastReceiver.PendingResult? = goAsync()
        super.onReceive(context, intent)
        WeatherRepo.refreshAsync(context, pending)
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        SecondsWidgets.refresh(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: android.os.Bundle,
    ) {
        SecondsWidgets.refresh(context)
    }

    override fun onEnabled(context: Context) {
        SecondsWidgets.refresh(context)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        SecondsWidgets.forget(context, appWidgetIds)
    }

    override fun onDisabled(context: Context) {
        if (!SecondsWidgets.hasWidgets(context)) SecondsWidgets.cancel(context)
    }
}

class SecondsBlackWidget : SecondsWidgetProvider()

class SecondsWhiteWidget : SecondsWidgetProvider()

class SecondsSyncReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending: BroadcastReceiver.PendingResult? = goAsync()
        SecondsWidgets.refresh(context)
        WeatherRepo.refreshAsync(context, pending)
    }
}
