package com.example.iosclock.ui

import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.SwitchColors
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Colours of the (light) Alarm pages. */
object AlarmColors {
    val Blue = Color(0xFF1F7AFF)
    val Gray = Color(0xFF8E8E93)
    val LightGray = Color(0xFFBDBDC2)
    val Divider = Color(0xFFEDEDED)
    val Track = Color(0xFFD6D6DA)
}

@Composable
fun AlarmTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = AlarmColors.Blue,
            background = Color.White,
            surface = Color.White,
            surfaceContainer = Color.White,
            surfaceContainerHigh = Color.White,
            onBackground = Color.Black,
            onSurface = Color.Black,
        ),
        shapes = MaterialTheme.shapes.copy(extraSmall = RoundedCornerShape(16.dp)),
        content = content,
    )
}

@Composable
fun alarmSwitchColors(): SwitchColors = SwitchDefaults.colors(
    checkedThumbColor = Color.White,
    checkedTrackColor = AlarmColors.Blue,
    checkedBorderColor = AlarmColors.Blue,
    uncheckedThumbColor = Color.White,
    uncheckedTrackColor = AlarmColors.Track,
    uncheckedBorderColor = AlarmColors.Track,
)

@Composable
fun alarmRadioColors() = RadioButtonDefaults.colors(
    selectedColor = AlarmColors.Blue,
    unselectedColor = AlarmColors.Gray,
)

@Composable
fun alarmCheckboxColors() = CheckboxDefaults.colors(
    checkedColor = AlarmColors.Blue,
    uncheckedColor = AlarmColors.Gray,
    checkmarkColor = Color.White,
)
