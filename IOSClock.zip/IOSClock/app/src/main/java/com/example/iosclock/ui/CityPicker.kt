package com.example.iosclock.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId
import java.util.Locale
import kotlin.math.abs

data class City(val id: String, val name: String, val country: String)

private val regions = listOf("Africa/", "America/", "Asia/", "Atlantic/", "Australia/", "Europe/", "Indian/", "Pacific/")

private fun countryOf(id: String): String = try {
    val code = android.icu.util.TimeZone.getRegion(id)
    if (code.length == 2) Locale.Builder().setRegion(code).build().getDisplayCountry(Locale.ENGLISH) else ""
} catch (e: Exception) {
    ""
}

/** Every city of the IANA time zone database (the phone's own copy), with its country. */
private val allCities: List<City> by lazy {
    ZoneId.getAvailableZoneIds()
        .filter { id -> regions.any { id.startsWith(it) } }
        .map { id -> City(id, cityName(id), countryOf(id)) }
        .distinctBy { it.name + "|" + it.country }
        .sortedBy { it.name }
}

fun gmtLabel(id: String): String {
    val sec = try {
        ZoneId.of(id).rules.getOffset(Instant.now()).totalSeconds
    } catch (e: Exception) {
        0
    }
    val a = abs(sec)
    val sign = if (sec < 0) "-" else "+"
    return "GMT $sign${a / 3600}:${((a % 3600) / 60).toString().padStart(2, '0')}"
}

@Composable
fun CityPickerScreen(onBack: () -> Unit, onPick: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    val results = remember(query) {
        val q = query.trim()
        if (q.isEmpty()) allCities
        else allCities.filter { it.name.contains(q, ignoreCase = true) || it.country.contains(q, ignoreCase = true) }
    }
    val state = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val letters = remember { ('A'..'Z').toList() }
    val firstIndex = remember(results) {
        letters.associateWith { l -> results.indexOfFirst { it.name.firstOrNull()?.uppercaseChar() == l } }
    }
    val current by remember(results) {
        derivedStateOf { results.getOrNull(state.firstVisibleItemIndex)?.name?.firstOrNull()?.uppercaseChar() }
    }
    var indexHeight by remember { mutableIntStateOf(1) }

    fun jump(l: Char) {
        val target = letters.filter { it >= l }.firstNotNullOfOrNull { c -> firstIndex[c]?.takeIf { it >= 0 } }
        if (target != null) scope.launch { state.scrollToItem(target) }
    }

    fun letterAt(y: Float): Char = letters[(y / indexHeight * letters.size).toInt().coerceIn(0, letters.size - 1)]

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.Black)
            }
            TextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("Search for cities", color = Gray99) },
                leadingIcon = { Icon(Icons.Filled.Search, null, tint = Gray99) },
                shape = RoundedCornerShape(28.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFFEDEDED),
                    unfocusedContainerColor = Color(0xFFEDEDED),
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = ClockBlue,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                ),
                modifier = Modifier.weight(1f).padding(end = 8.dp),
            )
        }
        Box(Modifier.weight(1f)) {
            LazyColumn(state = state, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(end = 28.dp)) {
                items(results, key = { it.id }) { c ->
                    Column(
                        Modifier.fillMaxWidth().clickable { onPick(c.id) }.padding(horizontal = 24.dp, vertical = 14.dp),
                    ) {
                        Text(c.name, color = Color(0xFF333333), fontSize = 18.sp)
                        val sub = if (c.country.isEmpty()) gmtLabel(c.id) else c.country + ", " + gmtLabel(c.id)
                        Text(sub, color = Gray99, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
                    }
                }
            }
            Column(
                Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .width(28.dp)
                    .onSizeChanged { indexHeight = maxOf(1, it.height) }
                    .pointerInput(Unit) { detectTapGestures { o -> jump(letterAt(o.y)) } }
                    .pointerInput(Unit) { detectVerticalDragGestures { change, _ -> jump(letterAt(change.position.y)) } },
                verticalArrangement = Arrangement.SpaceEvenly,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                letters.forEach { l ->
                    Text(
                        l.toString(),
                        fontSize = 11.sp,
                        color = if (current == l) ClockBlue else Gray99,
                    )
                }
            }
        }
    }
}
