package com.example.iosclock.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Orange = Color(0xFFFF9F0A)
val Subtle = Color(0xFF8E8E93)
val CardBg = Color(0xFF1C1C1E)
val CardBg2 = Color(0xFF2C2C2E)
val IosGreen = Color(0xFF30D158)
val IosRed = Color(0xFFFF453A)

private val scheme = darkColorScheme(
    primary = Orange,
    background = Color.Black,
    surface = CardBg,
    surfaceVariant = CardBg2,
    onBackground = Color.White,
    onSurface = Color.White,
    onSurfaceVariant = Subtle,
)

@Composable
fun IOSClockTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
