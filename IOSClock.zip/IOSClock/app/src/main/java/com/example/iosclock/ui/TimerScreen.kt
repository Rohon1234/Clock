package com.example.iosclock.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.iosclock.ClockViewModel
import com.example.iosclock.TimerRoute
import com.example.iosclock.alarm.TimerPreset
import kotlinx.coroutines.delay

@Composable
fun TimerScreen(vm: ClockViewModel) {
    AlarmTheme {
        Box(Modifier.fillMaxSize().background(PageBg)) {
            when (vm.timerRoute) {
                TimerRoute.MAIN -> if (vm.tmActive) TimerRunning(vm) else TimerMain(vm)
                TimerRoute.EDIT -> TimerEditScreen(vm)
                TimerRoute.SOUND -> SoundPicker(
                    "Timer Sound",
                    vm.tmSound,
                    { vm.setTimerSound(it) },
                    { vm.timerRoute = TimerRoute.MAIN },
                )
                TimerRoute.SETTINGS -> SettingsPage { vm.timerRoute = TimerRoute.MAIN }
            }
        }
    }
}

/** Hours, minutes and seconds wheels with the small h / m / s labels. */
@Composable
fun HmsPicker(h: Int, m: Int, s: Int, itemH: Dp = 52.dp, onChange: (Int, Int, Int) -> Unit) {
    var hh by remember { mutableIntStateOf(h) }
    var mm by remember { mutableIntStateOf(m) }
    var ss by remember { mutableIntStateOf(s) }
    val hours = remember { (0..23).map { it.toString().padStart(2, '0') } }
    val sixty = remember { (0..59).map { it.toString().padStart(2, '0') } }

    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        WheelPicker(hours, hh, loop = true, itemH = itemH, width = 70.dp) {
            hh = it
            onChange(hh, mm, ss)
        }
        Text("h", color = Gray99, fontSize = 16.sp, modifier = Modifier.padding(end = 10.dp))
        WheelPicker(sixty, mm, loop = true, itemH = itemH, width = 70.dp) {
            mm = it
            onChange(hh, mm, ss)
        }
        Text("m", color = Gray99, fontSize = 16.sp, modifier = Modifier.padding(end = 10.dp))
        WheelPicker(sixty, ss, loop = true, itemH = itemH, width = 70.dp) {
            ss = it
            onChange(hh, mm, ss)
        }
        Text("s", color = Gray99, fontSize = 16.sp)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TimerMain(vm: ClockViewModel) {
    var activeId by remember { mutableStateOf<Int?>(null) }
    var confirm by remember { mutableStateOf<TimerPreset?>(null) }

    Column(Modifier.fillMaxSize()) {
        PageTitleBar("Timer") { SettingsMenuButton { vm.timerRoute = TimerRoute.SETTINGS } }
        key(vm.pickerVersion) {
            HmsPicker(vm.tmH, vm.tmM, vm.tmS, itemH = 44.dp) { h, m, s ->
                vm.tmH = h
                vm.tmM = m
                vm.tmS = s
            }
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(vm.presets.toList(), key = { it.id }) { p ->
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(96.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(CardGray)
                        .combinedClickable(
                            onClick = {
                                activeId = null
                                vm.tmPick(p)
                            },
                            onLongClick = { activeId = p.id },
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(stickerOf(p.sticker).icon, null, tint = IconGray, modifier = Modifier.size(28.dp))
                        Text(p.name, color = Color.Black, fontSize = 16.sp, maxLines = 1, modifier = Modifier.padding(top = 4.dp))
                        Text(hmsText(p.seconds.toLong()), color = Gray99, fontSize = 13.sp)
                    }
                    if (activeId == p.id) {
                        Row(
                            Modifier.fillMaxSize().background(Color(0x66FFFFFF)),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            CircleAction(Icons.Filled.Edit, "Edit") {
                                activeId = null
                                vm.tmStartEdit(p)
                            }
                            Box(Modifier.size(16.dp))
                            CircleAction(Icons.Filled.Delete, "Delete") {
                                activeId = null
                                confirm = p
                            }
                        }
                    }
                }
            }
            item {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(96.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(CardGray)
                        .clickable {
                            activeId = null
                            vm.tmStartNew()
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.Add, "Add timer", tint = IconGray, modifier = Modifier.size(32.dp))
                }
            }
        }
        ControlsRow(
            left = {},
            center = { BluePlayButton(playing = false) { vm.tmStart() } },
            right = { GrayIconButton(Icons.Filled.Notifications, "Timer sound") { vm.timerRoute = TimerRoute.SOUND } },
        )
    }

    confirm?.let { p ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            containerColor = Color.White,
            title = { Text("Delete timer?", color = Color.Black) },
            text = { Text(p.name + "  " + hmsText(p.seconds.toLong()), color = Gray99) },
            confirmButton = {
                TextButton(onClick = {
                    vm.tmDeletePreset(p)
                    confirm = null
                }) { Text("Delete", color = ClockBlue) }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel", color = ClockBlue) } },
        )
    }
}

@Composable
private fun CircleAction(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(ClockBlue).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, desc, tint = Color.White, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun TimerRunning(vm: ClockViewModel) {
    var rem by remember { mutableLongStateOf(vm.tmRemainingNow()) }
    LaunchedEffect(Unit) {
        while (true) {
            if (vm.tmRunning) withFrameMillis { } else delay(200)
            rem = vm.tmRemainingNow()
            vm.tmCheckFinished()
        }
    }
    BackHandler { vm.tmCancel() }

    val total = vm.tmTotal.coerceAtLeast(1L)
    val fraction = (rem.toFloat() / total.toFloat()).coerceIn(0f, 1f)

    Column(Modifier.fillMaxSize()) {
        PageTitleBar("Timer")
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(Modifier.size(290.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 18.dp.toPx()
                    val gap = 24f
                    val start = -90f + gap / 2f
                    val full = 360f - gap
                    val topLeft = Offset(stroke / 2f, stroke / 2f)
                    val arcSize = Size(size.width - stroke, size.height - stroke)
                    drawArc(RingTrack, start, full, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                    if (fraction > 0f) {
                        drawArc(ClockBlue, start, full * fraction, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                    }
                }
                Text(
                    hmsText((rem + 999) / 1000),
                    color = Color.Black,
                    style = TextStyle(fontSize = 44.sp, fontWeight = FontWeight.Medium, fontFeatureSettings = "tnum"),
                )
            }
        }
        ControlsRow(
            left = { GrayIconButton(Icons.Filled.Refresh, "Reset") { vm.tmReset() } },
            center = {
                BluePlayButton(playing = vm.tmRunning) { if (vm.tmRunning) vm.tmPause() else vm.tmResume() }
            },
            right = { GrayIconButton(Icons.Filled.Notifications, "Timer sound") { vm.timerRoute = TimerRoute.SOUND } },
        )
    }
}
