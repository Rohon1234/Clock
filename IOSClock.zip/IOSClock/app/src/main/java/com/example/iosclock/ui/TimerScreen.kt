package com.example.iosclock.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.iosclock.ClockViewModel
import kotlinx.coroutines.delay
import java.time.ZonedDateTime

private val tabular = TextStyle(fontFeatureSettings = "tnum")

@Composable
fun TimerScreen(vm: ClockViewModel) {
    val is24 = is24Hour()
    var remaining by remember { mutableLongStateOf(vm.tmRemainingNow()) }
    LaunchedEffect(vm.tmActive, vm.tmRunning) {
        remaining = vm.tmRemainingNow()
        while (vm.tmActive && vm.tmRunning) {
            vm.tmCheckFinished()
            remaining = vm.tmRemainingNow()
            delay(50)
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            "Timer",
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier.align(Alignment.Start).padding(top = 56.dp),
        )
        Spacer(Modifier.height(24.dp))

        if (vm.tmActive) {
            val progress = if (vm.tmTotal > 0) remaining.toFloat() / vm.tmTotal else 0f
            Box(Modifier.size(300.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 10.dp.toPx()
                    val diameter = size.minDimension - stroke
                    val topLeft = Offset(stroke / 2, stroke / 2)
                    drawArc(
                        color = CardBg2, startAngle = 0f, sweepAngle = 360f, useCenter = false,
                        topLeft = topLeft, size = Size(diameter, diameter), style = Stroke(stroke),
                    )
                    drawArc(
                        color = Orange, startAngle = -90f, sweepAngle = 360f * progress, useCenter = false,
                        topLeft = topLeft, size = Size(diameter, diameter),
                        style = Stroke(stroke, cap = StrokeCap.Round),
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        formatCountdown(remaining),
                        style = tabular,
                        color = Color.White,
                        fontSize = 60.sp,
                        fontWeight = FontWeight.Thin,
                    )
                    if (vm.tmRunning) {
                        val end = ZonedDateTime.now().plusNanos(remaining * 1_000_000L)
                        val (clock, ampm) = timeParts(end.toLocalTime(), is24)
                        Text("Ends $clock $ampm".trim(), color = Subtle, fontSize = 16.sp)
                    }
                }
            }
            Spacer(Modifier.height(32.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                RoundButton("Cancel", Color.White, CardBg2) { vm.tmCancel() }
                if (vm.tmRunning) {
                    RoundButton("Pause", Orange, Orange.copy(alpha = 0.25f)) { vm.tmPause() }
                } else {
                    RoundButton("Resume", IosGreen, IosGreen.copy(alpha = 0.25f)) { vm.tmResume() }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Wheel(24, vm.tmH, "hours") { vm.tmH = it }
                Wheel(60, vm.tmM, "min") { vm.tmM = it }
                Wheel(60, vm.tmS, "sec") { vm.tmS = it }
            }
            Spacer(Modifier.height(32.dp))
            val canStart = vm.tmH + vm.tmM + vm.tmS > 0
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                RoundButton("Cancel", Color.White, CardBg2, enabled = false) {}
                RoundButton("Start", IosGreen, IosGreen.copy(alpha = 0.25f), enabled = canStart) { vm.tmStart() }
            }
        }
    }
}

/** iOS-style snapping wheel. The list has two blank rows on each side so the centre row is the selection. */
@Composable
private fun Wheel(count: Int, selected: Int, label: String, onSelected: (Int) -> Unit) {
    val itemHeight = 44.dp
    val state = rememberLazyListState(initialFirstVisibleItemIndex = selected)
    val fling = rememberSnapFlingBehavior(state)
    LaunchedEffect(state) {
        snapshotFlow { state.isScrollInProgress to state.firstVisibleItemIndex }
            .collect { (scrolling, first) ->
                if (!scrolling) onSelected(first.coerceIn(0, count - 1))
            }
    }
    Box(Modifier.width(112.dp).height(itemHeight * 5)) {
        Box(
            Modifier
                .align(Alignment.Center)
                .fillMaxWidth()
                .height(itemHeight)
                .background(CardBg2, RoundedCornerShape(10.dp))
        )
        LazyColumn(state = state, flingBehavior = fling, modifier = Modifier.fillMaxSize()) {
            items(count + 4) { index ->
                val n = index - 2
                Box(Modifier.fillMaxWidth().height(itemHeight).padding(end = 36.dp), contentAlignment = Alignment.CenterEnd) {
                    if (n in 0 until count) {
                        Text(n.toString(), color = Color.White, fontSize = 26.sp, style = tabular)
                    }
                }
            }
        }
        Text(
            label,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 4.dp),
        )
    }
}
