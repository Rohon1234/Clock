package com.example.iosclock.ui

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.iosclock.AlarmRoute
import com.example.iosclock.ClockViewModel
import com.example.iosclock.alarm.SOUND_DEFAULT
import com.example.iosclock.alarm.SOUND_SILENT
import com.example.iosclock.alarm.SettingsStore
import com.example.iosclock.alarm.Sounds

// ---------------------------------------------------------------- shared pieces

@Composable
private fun SubTopBar(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.Black)
        }
        Text(title, color = Color.Black, fontSize = 22.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 8.dp))
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text,
        color = AlarmColors.Gray,
        fontSize = 14.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.fillMaxWidth().padding(start = 24.dp, end = 24.dp, top = 20.dp, bottom = 6.dp),
    )
}

@Composable
private fun RadioRow(title: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, color = Color.Black, fontSize = 17.sp, modifier = Modifier.weight(1f))
        RadioButton(selected = selected, onClick = null, colors = alarmRadioColors())
    }
}

// ---------------------------------------------------------------- alarm sound

private class PreviewPlayer(private val ctx: Context) {
    private var current: Ringtone? = null

    fun play(key: String) {
        stop()
        val uri = Sounds.resolveUri(key) ?: return
        current = try {
            RingtoneManager.getRingtone(ctx, uri)?.also {
                it.audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                it.play()
            }
        } catch (e: Exception) {
            null
        }
    }

    fun stop() {
        try {
            current?.stop()
        } catch (e: Exception) {
            // ignore
        }
        current = null
    }
}

@Composable
fun SoundScreen(vm: ClockViewModel) {
    val ctx = LocalContext.current
    val d = vm.draft
    if (d == null) {
        LaunchedEffect(Unit) { vm.alarmRoute = AlarmRoute.LIST }
        return
    }
    var custom by remember { mutableStateOf(Sounds.customSounds(ctx)) }
    val device = remember { Sounds.deviceSounds(ctx) }
    val player = remember { PreviewPlayer(ctx) }
    DisposableEffect(Unit) { onDispose { player.stop() } }

    fun choose(key: String) {
        vm.draft = vm.draft?.copy(sound = key)
        player.play(key)
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // some providers do not offer a persistable grant
            }
            var title = "My sound"
            try {
                ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) title = c.getString(0).substringBeforeLast('.')
                }
            } catch (e: Exception) {
                // keep the default title
            }
            Sounds.addCustom(ctx, uri.toString(), title)
            custom = Sounds.customSounds(ctx)
            choose(uri.toString())
        }
    }

    Column(Modifier.fillMaxSize()) {
        SubTopBar("Alarm Sound") { vm.alarmBack() }
        LazyColumn(Modifier.fillMaxSize()) {
            item { SectionHeader("Your Sounds") }
            item {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { picker.launch(arrayOf("audio/*")) }
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Add New", color = Color.Black, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    Icon(Icons.Filled.Add, contentDescription = "Add new sound", tint = Color.Black)
                }
            }
            items(custom, key = { "c" + it.key }) { s ->
                RadioRow(s.title, d.sound == s.key) { choose(s.key) }
            }
            item { SectionHeader("Device Sounds") }
            item { RadioRow("Silent", d.sound == SOUND_SILENT) { choose(SOUND_SILENT) } }
            item { RadioRow("Default Alarm Sound", d.sound == SOUND_DEFAULT) { choose(SOUND_DEFAULT) } }
            items(device, key = { "d" + it.key }) { s ->
                RadioRow(s.title, d.sound == s.key) { choose(s.key) }
            }
        }
    }
}

// ---------------------------------------------------------------- snooze

@Composable
fun SnoozeScreen(vm: ClockViewModel) {
    val d = vm.draft
    if (d == null) {
        LaunchedEffect(Unit) { vm.alarmRoute = AlarmRoute.LIST }
        return
    }
    Column(Modifier.fillMaxSize()) {
        SubTopBar("Snooze") { vm.alarmBack() }
        LazyColumn(Modifier.fillMaxSize()) {
            item { SectionHeader("Ring Interval") }
            items(listOf(5, 10, 15, 20, 30)) { m ->
                RadioRow("$m Minutes", d.snoozeMinutes == m) { vm.draft = vm.draft?.copy(snoozeMinutes = m) }
            }
            item { HorizontalDivider(color = AlarmColors.Divider, modifier = Modifier.padding(top = 8.dp)) }
            item { SectionHeader("Frequency") }
            items(listOf(0, 1, 3, 5, 10)) { t ->
                RadioRow(if (t == 1) "1 Time" else "$t Times", d.snoozeTimes == t) {
                    vm.draft = vm.draft?.copy(snoozeTimes = t)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- settings

@Composable
private fun SettingRow(title: String, subtitle: String?, onClick: (() -> Unit)?, trailing: @Composable () -> Unit) {
    val base = if (onClick != null) Modifier.fillMaxWidth().clickable(onClick = onClick) else Modifier.fillMaxWidth()
    Row(base.padding(horizontal = 24.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = Color.Black, fontSize = 17.sp)
            if (subtitle != null) Text(subtitle, color = AlarmColors.Gray, fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp))
        }
        trailing()
    }
}

@Composable
fun AlarmSettingsScreen(vm: ClockViewModel) {
    val ctx = LocalContext.current
    var timerSounds by remember { mutableStateOf(SettingsStore.get(ctx, "timer_sounds", true)) }
    var stopwatchSounds by remember { mutableStateOf(SettingsStore.get(ctx, "stopwatch_sounds", true)) }

    Column(Modifier.fillMaxSize()) {
        SubTopBar("Settings") { vm.alarmBack() }
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                SettingRow(
                    title = "To set dual clocks, please go to Settings > System > Date & Time.",
                    subtitle = null,
                    onClick = {
                        try {
                            ctx.startActivity(Intent(Settings.ACTION_DATE_SETTINGS))
                        } catch (e: Exception) {
                            // no date settings page on this phone
                        }
                    },
                ) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = AlarmColors.Gray) }
            }
            item { HorizontalDivider(color = AlarmColors.Divider, modifier = Modifier.padding(vertical = 4.dp)) }

            item { SectionHeader("Alarm") }
            item {
                SettingRow("National/Regional Public Holidays", "Bangladesh", onClick = {}) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = AlarmColors.Gray)
                }
            }

            item { SectionHeader("Timer") }
            item {
                SettingRow("Timer Running Sounds", null, onClick = null) {
                    Switch(
                        checked = timerSounds,
                        onCheckedChange = {
                            timerSounds = it
                            SettingsStore.set(ctx, "timer_sounds", it)
                        },
                        colors = alarmSwitchColors(),
                    )
                }
            }

            item { SectionHeader("Stopwatch") }
            item {
                SettingRow("Stopwatch Running Sounds", null, onClick = null) {
                    Switch(
                        checked = stopwatchSounds,
                        onCheckedChange = {
                            stopwatchSounds = it
                            SettingsStore.set(ctx, "stopwatch_sounds", it)
                        },
                        colors = alarmSwitchColors(),
                    )
                }
            }

            item { SectionHeader("About") }
            item { SettingRow("Version Number", "8.7.11.083", onClick = null) {} }
        }
    }
}
