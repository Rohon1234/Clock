package com.example.iosclock.alarm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** A saved timer card: name, duration, sticker (name of the Sticker enum) and lock screen flag. */
data class TimerPreset(
    val id: Int,
    val name: String,
    val seconds: Int,
    val sticker: String,
    val lockScreen: Boolean = true,
)

object TimerStore {
    private const val PREFS = "clock_prefs"
    private const val KEY = "timer_presets"
    private const val KEY_SOUND = "timer_sound"

    private fun defaults() = listOf(
        TimerPreset(1, "Meeting", 20 * 60, "MEETING"),
        TimerPreset(2, "Sleep", 10 * 60, "SLEEP"),
        TimerPreset(3, "Exercise", 15 * 60, "EXERCISE"),
    )

    fun load(ctx: Context): List<TimerPreset> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return defaults()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                TimerPreset(
                    id = o.getInt("id"),
                    name = o.optString("name", "Timer"),
                    seconds = o.optInt("sec", 0),
                    sticker = o.optString("sticker", "TIMER"),
                    lockScreen = o.optBoolean("lock", true),
                )
            }
        } catch (e: Exception) {
            defaults()
        }
    }

    fun save(ctx: Context, list: List<TimerPreset>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("name", it.name)
                    .put("sec", it.seconds)
                    .put("sticker", it.sticker)
                    .put("lock", it.lockScreen)
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun sound(ctx: Context): String =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_SOUND, SOUND_DEFAULT) ?: SOUND_DEFAULT

    fun setSound(ctx: Context, key: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_SOUND, key).apply()
    }
}
