package com.example.iosclock.alarm

import android.content.Context
import android.media.RingtoneManager
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

data class SoundItem(val key: String, val title: String)

/** Alarm tones: the phone's own alarm sounds, plus audio files the user adds. */
object Sounds {
    private const val PREFS = "clock_prefs"
    private const val KEY_CUSTOM = "custom_sounds"

    private val fallbackNames = listOf(
        "Affability Cristal", "Ancient Stories", "Beep", "Broad", "Calm", "Carouse", "Continuous",
    )

    fun deviceSounds(ctx: Context): List<SoundItem> {
        val out = mutableListOf<SoundItem>()
        try {
            val rm = RingtoneManager(ctx)
            rm.setType(RingtoneManager.TYPE_ALARM)
            rm.cursor.use { c ->
                while (c.moveToNext()) {
                    val uri = rm.getRingtoneUri(c.position)
                    val title = c.getString(RingtoneManager.TITLE_COLUMN_INDEX)
                    out.add(SoundItem(uri.toString(), title))
                }
            }
        } catch (e: Exception) {
            // fall through to the fallback list
        }
        if (out.isEmpty()) fallbackNames.forEach { out.add(SoundItem("fallback:$it", it)) }
        return out
    }

    fun customSounds(ctx: Context): List<SoundItem> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_CUSTOM, null)
            ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                SoundItem(o.getString("uri"), o.getString("title"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addCustom(ctx: Context, uri: String, title: String) {
        val list = customSounds(ctx).filter { it.key != uri } + SoundItem(uri, title)
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("uri", it.key).put("title", it.title)) }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_CUSTOM, arr.toString()).apply()
    }

    fun defaultUri(): Uri? =
        RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

    /** The sound to play for a saved key, or null for silent. */
    fun resolveUri(key: String): Uri? = when {
        key == SOUND_SILENT -> null
        key == SOUND_DEFAULT || key.startsWith("fallback:") -> defaultUri()
        else -> try {
            Uri.parse(key)
        } catch (e: Exception) {
            defaultUri()
        }
    }

    private fun defaultTitle(ctx: Context): String? = try {
        val uri = RingtoneManager.getActualDefaultRingtoneUri(ctx, RingtoneManager.TYPE_ALARM)
        if (uri == null) null else RingtoneManager.getRingtone(ctx, uri)?.getTitle(ctx)
    } catch (e: Exception) {
        null
    }

    /** Text for the "Alarm Sound" row, like "Default (Star)". */
    fun label(ctx: Context, key: String): String = when {
        key == SOUND_SILENT -> "Silent"
        key == SOUND_DEFAULT -> defaultTitle(ctx)?.let { "Default ($it)" } ?: "Default"
        key.startsWith("fallback:") -> key.removePrefix("fallback:")
        else -> (customSounds(ctx) + deviceSounds(ctx)).firstOrNull { it.key == key }?.title ?: "Custom"
    }
}
