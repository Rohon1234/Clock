package com.example.iosclock.ui

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.iosclock.ClockViewModel
import com.example.iosclock.TimerRoute
import kotlinx.coroutines.launch

enum class Sticker(val label: String, val icon: ImageVector) {
    TIMER("Timer", Icons.Filled.HourglassBottom),
    MEETING("Meeting", Icons.Filled.Slideshow),
    SLEEP("Sleep", Icons.Filled.Bedtime),
    EXERCISE("Exercise", Icons.Filled.FitnessCenter),
    MINDFULNESS("Mindfulness", Icons.Filled.SelfImprovement),
    WORK("Work", Icons.Filled.Work),
}

fun stickerOf(name: String): Sticker = Sticker.entries.firstOrNull { it.name == name } ?: Sticker.TIMER

@Composable
fun TimerEditScreen(vm: ClockViewModel) {
    val ctx = LocalContext.current
    val d = vm.tmDraft
    if (d == null) {
        LaunchedEffect(Unit) { vm.timerRoute = TimerRoute.MAIN }
        return
    }
    var h by remember { mutableIntStateOf(d.seconds / 3600) }
    var m by remember { mutableIntStateOf((d.seconds / 60) % 60) }
    var s by remember { mutableIntStateOf(d.seconds % 60) }
    var name by remember { mutableStateOf(d.name) }
    var sticker by remember { mutableStateOf(d.sticker) }
    var lock by remember { mutableStateOf(d.lockScreen) }
    var showName by remember { mutableStateOf(false) }
    var showSticker by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { vm.tmBack() }) { Icon(Icons.Filled.Close, "Close", tint = Color.Black) }
            Text(
                "Edit Timer",
                color = Color.Black,
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f).padding(start = 8.dp),
            )
            IconButton(onClick = {
                val total = h * 3600 + m * 60 + s
                if (total <= 0) {
                    Toast.makeText(ctx, "Choose a time first", Toast.LENGTH_SHORT).show()
                } else {
                    vm.tmCommit(d.copy(name = name.ifBlank { "Timer" }, seconds = total, sticker = sticker, lockScreen = lock))
                }
            }) { Icon(Icons.Filled.Check, "Save", tint = Color.Black) }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            HmsPicker(h, m, s) { a, b, c ->
                h = a
                m = b
                s = c
            }
            Spacer(Modifier.height(8.dp))
            OptionRow("Timer Name", name.ifBlank { "Timer" }) { showName = true }
            OptionRow("Sticker", stickerOf(sticker).label) { showSticker = true }
            SwitchRow("Show on Lock Screen", lock) { lock = it }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showName) {
        LabelDialog(
            initial = name,
            onDismiss = { showName = false },
            onDone = {
                name = it
                showName = false
            },
            title = "Timer Name",
        )
    }
    if (showSticker) {
        StickerSheet(
            selected = sticker,
            onDismiss = { showSticker = false },
            onPick = {
                sticker = it
                showSticker = false
            },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StickerSheet(selected: String, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color.White,
        scrimColor = Color(0x66000000),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = null,
    ) {
        Column(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            Text(
                "Sticker",
                color = Color.Black,
                fontSize = 22.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(start = 8.dp),
            )
            Sticker.entries.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    row.forEach { st ->
                        val on = st.name == selected
                        val color = if (on) ClockBlue else IconGray
                        Column(
                            Modifier
                                .weight(1f)
                                .clickable {
                                    scope.launch { sheetState.hide() }.invokeOnCompletion { onPick(st.name) }
                                }
                                .padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Icon(st.icon, st.label, tint = color, modifier = Modifier.size(36.dp))
                            Text(st.label, color = color, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                }
            }
        }
    }
}
