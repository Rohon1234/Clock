package com.example.iosclock.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.RemoveCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TimePickerDefaults
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.example.iosclock.ClockViewModel
import com.example.iosclock.alarm.Alarm
import java.time.LocalTime
import java.time.format.TextStyle
import java.time.DayOfWeek
import java.util.Locale

private fun repeatText(days: Set<Int>): String = when {
    days.isEmpty() -> "Never"
    days.size == 7 -> "Every day"
    days == setOf(1, 2, 3, 4, 5) -> "Weekdays"
    days == setOf(6, 7) -> "Weekends"
    else -> days.sorted().joinToString(", ") {
        DayOfWeek.of(it).getDisplayName(TextStyle.SHORT, Locale.getDefault())
    }
}

@Composable
fun AlarmScreen(vm: ClockViewModel) {
    var editing by remember { mutableStateOf(false) }
    var dialogAlarm by remember { mutableStateOf<Alarm?>(null) }
    val is24 = is24Hour()

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { editing = !editing }) {
                Text(if (editing) "Done" else "Edit", color = Orange, fontSize = 18.sp)
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { dialogAlarm = vm.newAlarm() }) {
                Icon(Icons.Filled.Add, contentDescription = "Add alarm", tint = Orange)
            }
        }
        Text("Alarms", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.padding(top = 8.dp))

        LazyColumn(Modifier.fillMaxSize()) {
            items(vm.alarms.toList(), key = { it.id }) { alarm ->
                val (clock, ampm) = timeParts(LocalTime.of(alarm.hour, alarm.minute), is24)
                val dim = if (alarm.enabled) Color.White else Subtle
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { dialogAlarm = alarm }
                        .padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (editing) {
                        IconButton(onClick = { vm.deleteAlarm(alarm) }) {
                            Icon(Icons.Filled.RemoveCircle, contentDescription = "Delete", tint = IosRed)
                        }
                    }
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(clock, color = dim, fontSize = 52.sp, fontWeight = FontWeight.Light)
                            if (ampm.isNotEmpty()) {
                                Text(
                                    ampm,
                                    color = dim,
                                    fontSize = 24.sp,
                                    modifier = Modifier.padding(start = 4.dp, bottom = 10.dp),
                                )
                            }
                        }
                        val sub = listOf(alarm.label.ifBlank { "Alarm" }, repeatText(alarm.days))
                            .joinToString(", ")
                        Text(sub, color = if (alarm.enabled) Color.White else Subtle, fontSize = 15.sp)
                    }
                    Switch(
                        checked = alarm.enabled,
                        onCheckedChange = { vm.toggleAlarm(alarm) },
                        colors = SwitchDefaults.colors(
                            checkedTrackColor = IosGreen,
                            checkedThumbColor = Color.White,
                            uncheckedTrackColor = CardBg2,
                            uncheckedThumbColor = Color.White,
                            uncheckedBorderColor = CardBg2,
                        ),
                    )
                }
                HorizontalDivider(color = CardBg2)
            }
        }
    }

    dialogAlarm?.let { current ->
        AlarmDialog(
            initial = current,
            is24 = is24,
            onDismiss = { dialogAlarm = null },
            onSave = { vm.saveAlarm(it); dialogAlarm = null },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AlarmDialog(
    initial: Alarm,
    is24: Boolean,
    onDismiss: () -> Unit,
    onSave: (Alarm) -> Unit,
) {
    val timeState = rememberTimePickerState(initial.hour, initial.minute, is24)
    var label by remember { mutableStateOf(initial.label) }
    var days by remember { mutableStateOf(initial.days) }
    val letters = listOf("M", "T", "W", "T", "F", "S", "S")

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardBg,
        modifier = Modifier.fillMaxWidth(0.94f),
        properties = DialogProperties(usePlatformDefaultWidth = false),
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                TimePicker(
                    state = timeState,
                    colors = TimePickerDefaults.colors(
                        selectorColor = Orange,
                        clockDialColor = CardBg2,
                        periodSelectorSelectedContainerColor = Orange.copy(alpha = 0.3f),
                        timeSelectorSelectedContainerColor = Orange.copy(alpha = 0.3f),
                    ),
                )
                Spacer(Modifier.padding(top = 12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    letters.forEachIndexed { index, letter ->
                        val day = index + 1
                        val on = day in days
                        Box(
                            Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(if (on) Orange else CardBg2)
                                .clickable { days = if (on) days - day else days + day },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(letter, color = if (on) Color.Black else Color.White, fontWeight = FontWeight.Medium)
                        }
                    }
                }
                Spacer(Modifier.padding(top = 12.dp))
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it.take(40) },
                    singleLine = true,
                    placeholder = { Text("Label") },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    initial.copy(
                        hour = timeState.hour,
                        minute = timeState.minute,
                        label = label.trim(),
                        days = days,
                        enabled = true,
                    )
                )
            }) { Text("Save", color = Orange) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Orange) } },
    )
}
