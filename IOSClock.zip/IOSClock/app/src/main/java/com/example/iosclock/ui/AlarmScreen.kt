package com.example.iosclock.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.iosclock.AlarmRoute
import com.example.iosclock.ClockViewModel
import com.example.iosclock.alarm.Alarm
import java.time.DayOfWeek
import java.time.format.TextStyle
import java.util.Locale

fun hour12(h: Int): Int = if (h % 12 == 0) 12 else h % 12

fun ampm(h: Int): String = if (h < 12) "AM" else "PM"

fun timeText(h: Int, m: Int): String = "${hour12(h)}:${m.toString().padStart(2, '0')}"

/** Sunday first, because that is how the repeat list is ordered. */
val weekOrder = listOf(7, 1, 2, 3, 4, 5, 6)

fun repeatText(days: Set<Int>): String = when {
    days.isEmpty() -> "Once"
    days.size == 7 -> "Every day"
    days == setOf(1, 2, 3, 4, 5) -> "Mon to Fri"
    else -> weekOrder.filter { it in days }.joinToString(", ") {
        DayOfWeek.of(it).getDisplayName(TextStyle.SHORT, Locale.ENGLISH)
    }
}

/** The whole Alarm tab: list page plus the pages opened from it. */
@Composable
fun AlarmScreen(vm: ClockViewModel) {
    AlarmTheme {
        Box(Modifier.fillMaxSize().background(Color.White)) {
            when (vm.alarmRoute) {
                AlarmRoute.LIST -> AlarmList(vm)
                AlarmRoute.EDIT -> AlarmEditScreen(vm)
                AlarmRoute.SOUND -> SoundScreen(vm)
                AlarmRoute.SNOOZE -> SnoozeScreen(vm)
                AlarmRoute.SETTINGS -> AlarmSettingsScreen(vm)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AlarmList(vm: ClockViewModel) {
    var menu by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Alarm?>(null) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 24.dp, end = 8.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Alarm",
                color = Color.Black,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = { vm.startNew() }) {
                Icon(Icons.Filled.Add, contentDescription = "Add alarm", tint = Color.Black, modifier = Modifier.size(28.dp))
            }
            Box {
                IconButton(onClick = { menu = true }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "More", tint = Color.Black)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Settings", color = Color.Black, fontSize = 16.sp) },
                        onClick = {
                            menu = false
                            vm.alarmRoute = AlarmRoute.SETTINGS
                        },
                    )
                }
            }
        }

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)) {
            items(vm.alarms.toList(), key = { it.id }) { alarm ->
                val on = alarm.enabled
                val main = if (on) Color.Black else AlarmColors.LightGray
                val subColor = if (on) Color(0xFF5F5F63) else AlarmColors.LightGray
                val sub = if (alarm.label.isBlank()) repeatText(alarm.days) else "${alarm.label}, ${repeatText(alarm.days)}"
                Row(
                    Modifier
                        .fillMaxWidth()
                        .combinedClickable(onClick = { vm.startEdit(alarm) }, onLongClick = { toDelete = alarm })
                        .padding(horizontal = 24.dp, vertical = 18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(timeText(alarm.hour, alarm.minute), color = main, fontSize = 52.sp, fontWeight = FontWeight.Light)
                            Text(
                                " " + ampm(alarm.hour),
                                color = main,
                                fontSize = 20.sp,
                                modifier = Modifier.padding(bottom = 10.dp),
                            )
                        }
                        Text(sub, color = subColor, fontSize = 15.sp)
                    }
                    Switch(
                        checked = on,
                        onCheckedChange = { vm.toggleAlarm(alarm) },
                        colors = alarmSwitchColors(),
                    )
                }
            }
        }
    }

    toDelete?.let { alarm ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            containerColor = Color.White,
            title = { Text("Delete alarm?", color = Color.Black) },
            text = { Text("${timeText(alarm.hour, alarm.minute)} ${ampm(alarm.hour)}", color = AlarmColors.Gray) },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteAlarm(alarm)
                    toDelete = null
                }) { Text("Delete", color = AlarmColors.Blue) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel", color = AlarmColors.Blue) } },
        )
    }
}
