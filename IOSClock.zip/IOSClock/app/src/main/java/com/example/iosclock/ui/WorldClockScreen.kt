package com.example.iosclock.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.RemoveCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.clickable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.iosclock.ClockViewModel
import kotlinx.coroutines.delay
import java.time.ZoneId
import java.time.ZonedDateTime

@Composable
fun WorldClockScreen(vm: ClockViewModel) {
    var now by remember { mutableStateOf(ZonedDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = ZonedDateTime.now()
            delay(1000L - (System.currentTimeMillis() % 1000L))
        }
    }
    var editing by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }
    val is24 = is24Hour()

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { editing = !editing }) {
                Text(if (editing) "Done" else "Edit", color = Orange, fontSize = 18.sp)
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { adding = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Add city", tint = Orange)
            }
        }
        Text("World Clock", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.padding(top = 8.dp))

        LazyColumn(Modifier.fillMaxSize()) {
            items(vm.zones.toList(), key = { it }) { id ->
                val zone = ZoneId.of(id)
                val t = now.withZoneSameInstant(zone)
                val diff = t.offset.totalSeconds - now.offset.totalSeconds
                val (clock, ampm) = timeParts(t.toLocalTime(), is24)
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (editing) {
                        IconButton(onClick = { vm.removeZone(id) }) {
                            Icon(Icons.Filled.RemoveCircle, contentDescription = "Remove", tint = IosRed)
                        }
                    }
                    Column(Modifier.weight(1f)) {
                        Text(
                            "${dayLabel(now.toLocalDate(), t.toLocalDate())}, ${offsetLabel(diff)}",
                            color = Subtle,
                            fontSize = 14.sp,
                        )
                        Text(cityName(id), color = Color.White, fontSize = 26.sp)
                    }
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(clock, color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Light)
                        if (ampm.isNotEmpty()) {
                            Text(
                                ampm,
                                color = Color.White,
                                fontSize = 20.sp,
                                modifier = Modifier.padding(start = 4.dp, bottom = 8.dp),
                            )
                        }
                    }
                }
                HorizontalDivider(color = CardBg2)
            }
        }
    }

    if (adding) {
        ZonePickerDialog(
            onDismiss = { adding = false },
            onPick = { vm.addZone(it); adding = false },
        )
    }
}

private val allZones: List<String> by lazy {
    ZoneId.getAvailableZoneIds()
        .filter { it.contains('/') && !it.startsWith("Etc/") && !it.startsWith("SystemV/") }
        .sorted()
}

@Composable
private fun ZonePickerDialog(onDismiss: () -> Unit, onPick: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    val results = remember(query) {
        val q = query.trim().replace(' ', '_')
        if (q.isEmpty()) allZones else allZones.filter { it.contains(q, ignoreCase = true) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardBg,
        title = { Text("Choose a City", color = Color.White) },
        text = {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text("Search") },
                    modifier = Modifier.fillMaxWidth(),
                )
                LazyColumn(Modifier.heightIn(max = 340.dp).padding(top = 8.dp)) {
                    items(results, key = { it }) { id ->
                        Column(
                            Modifier.fillMaxWidth().clickable { onPick(id) }.padding(vertical = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp),
                        ) {
                            Text(cityName(id), color = Color.White, fontSize = 17.sp)
                            Text(regionName(id), color = Subtle, fontSize = 13.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Orange) } },
    )
}
