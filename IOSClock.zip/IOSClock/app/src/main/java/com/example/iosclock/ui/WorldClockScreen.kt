package com.example.iosclock.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.iosclock.ClockViewModel
import com.example.iosclock.WorldRoute
import kotlinx.coroutines.delay
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun WorldClockScreen(vm: ClockViewModel) {
    AlarmTheme {
        Box(Modifier.fillMaxSize().background(PageBg)) {
            when (vm.worldRoute) {
                WorldRoute.MAIN -> WorldMain(vm)
                WorldRoute.ADD -> CityPickerScreen(
                    onBack = { vm.worldRoute = WorldRoute.MAIN },
                    onPick = {
                        vm.addZone(it)
                        vm.worldRoute = WorldRoute.MAIN
                    },
                )
                WorldRoute.SETTINGS -> SettingsPage { vm.worldRoute = WorldRoute.MAIN }
            }
        }
    }
}

private fun diffText(diff: Int): String {
    if (diff == 0) return "Same time"
    val a = abs(diff)
    val h = a / 3600
    val m = (a % 3600) / 60
    val hr = if (h == 1) "1 hr" else "$h hrs"
    val amount = when {
        m == 0 -> hr
        h == 0 -> "$m min"
        else -> "$hr $m min"
    }
    return amount + if (diff > 0) " ahead" else " behind"
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun WorldMain(vm: ClockViewModel) {
    var now by remember { mutableStateOf(ZonedDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = ZonedDateTime.now()
            delay(1000L - (System.currentTimeMillis() % 1000L))
        }
    }
    val is24 = is24Hour()
    var selected by remember { mutableStateOf(setOf<String>()) }
    val selecting = vm.worldSelecting
    BackHandler(enabled = selecting) {
        vm.worldSelecting = false
        selected = emptySet()
    }
    val rowH = 88.dp
    val rowHPx = with(LocalDensity.current) { rowH.toPx() }
    var draggingId by remember { mutableStateOf<String?>(null) }
    val dateFmt = remember { DateTimeFormatter.ofPattern("EEE, MMM d", Locale.ENGLISH) }

    Column(Modifier.fillMaxSize()) {
        if (selecting) {
            val n = selected.size
            val title = when (n) {
                0 -> "Select Items"
                1 -> "1 Item Selected"
                else -> "$n Items Selected"
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = {
                    vm.worldSelecting = false
                    selected = emptySet()
                }) { Icon(Icons.Filled.Close, "Close", tint = Color.Black) }
                Text(
                    title,
                    color = Color.Black,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f).padding(start = 8.dp),
                )
                Checkbox(
                    checked = vm.zones.isNotEmpty() && n == vm.zones.size,
                    onCheckedChange = { selected = if (it) vm.zones.toSet() else emptySet() },
                    colors = alarmCheckboxColors(),
                )
            }
        } else {
            PageTitleBar("World Clock") {
                IconButton(onClick = { vm.worldRoute = WorldRoute.ADD }) {
                    Icon(Icons.Filled.Add, "Add city", tint = Color.Black)
                }
                SettingsMenuButton { vm.worldRoute = WorldRoute.SETTINGS }
            }
        }

        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            item {
                val tzName = TimeZone.getTimeZone(now.zone).getDisplayName(
                    now.zone.rules.isDaylightSavings(now.toInstant()), TimeZone.LONG, Locale.ENGLISH,
                )
                val pattern = if (is24) "HH:mm:ss" else "h:mm:ss a"
                Column(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    AnalogFace(now, Modifier.size(240.dp))
                    Spacer(Modifier.height(24.dp))
                    Text(
                        DateTimeFormatter.ofPattern(pattern, Locale.ENGLISH).format(now),
                        color = Color.Black,
                        fontSize = 40.sp,
                        fontWeight = FontWeight.Medium,
                    )
                    Text(dateFmt.format(now), color = Color(0xFF444444), fontSize = 17.sp, modifier = Modifier.padding(top = 4.dp))
                    Text(tzName, color = Gray99, fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp))
                }
            }
            items(vm.zones.toList(), key = { it }) { id ->
                val t = now.withZoneSameInstant(ZoneId.of(id))
                val diff = t.offset.totalSeconds - now.offset.totalSeconds
                val on = id in selected
                var off by remember { mutableFloatStateOf(0f) }
                val dragging = draggingId == id
                val (clock, ampm) = timeParts(t.toLocalTime(), is24)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(rowH)
                        .zIndex(if (dragging) 1f else 0f)
                        .graphicsLayer { translationY = off }
                        .background(if (dragging) Color(0xFFEAEAEA) else PageBg)
                        .combinedClickable(
                            onClick = { if (selecting) selected = if (on) selected - id else selected + id },
                            onLongClick = {
                                if (!selecting) {
                                    vm.worldSelecting = true
                                    selected = setOf(id)
                                }
                            },
                        )
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (selecting) {
                        Icon(
                            Icons.Filled.DragHandle,
                            "Reorder",
                            tint = IconGray,
                            modifier = Modifier
                                .size(40.dp)
                                .padding(8.dp)
                                .pointerInput(Unit) {
                                    detectDragGestures(
                                        onDragStart = { draggingId = id },
                                        onDragEnd = {
                                            draggingId = null
                                            off = 0f
                                            vm.saveZones()
                                        },
                                        onDragCancel = {
                                            draggingId = null
                                            off = 0f
                                            vm.saveZones()
                                        },
                                    ) { change, amount ->
                                        change.consume()
                                        off += amount.y
                                        val idx = vm.zones.indexOf(id)
                                        if (off > rowHPx * 0.6f && idx in 0 until vm.zones.size - 1) {
                                            vm.moveZone(idx, idx + 1)
                                            off -= rowHPx
                                        } else if (off < -rowHPx * 0.6f && idx > 0) {
                                            vm.moveZone(idx, idx - 1)
                                            off += rowHPx
                                        }
                                    }
                                },
                        )
                        Checkbox(checked = on, onCheckedChange = null, colors = alarmCheckboxColors())
                    }
                    Column(Modifier.weight(1f).padding(start = if (selecting) 8.dp else 8.dp, end = 8.dp)) {
                        Text(cityName(id), color = Color.Black, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text(
                            dateFmt.format(t) + ", " + diffText(diff),
                            color = Gray99,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(top = 2.dp),
                        )
                    }
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(clock, color = Color.Black, fontSize = 32.sp, fontWeight = FontWeight.Light)
                        if (ampm.isNotEmpty()) {
                            Text(" $ampm", color = Color.Black, fontSize = 15.sp, modifier = Modifier.padding(bottom = 5.dp))
                        }
                    }
                }
            }
        }

        if (selecting) {
            val any = selected.isNotEmpty()
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .clickable(enabled = any) {
                        vm.removeZones(selected)
                        selected = emptySet()
                        vm.worldSelecting = false
                    }
                    .padding(vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(Icons.Filled.Delete, "Remove", tint = if (any) Color.Black else IconGray)
                Text("Remove", color = if (any) Color.Black else IconGray, fontSize = 12.sp)
            }
        }
    }
}

/** The big round analog clock, drawn on a Canvas from the given time. */
@Composable
fun AnalogFace(time: ZonedDateTime, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f
        val face = r * 0.94f
        for (i in 1..6) {
            drawCircle(Color(0x0D000000), radius = face + i * 1.5f.dp.toPx(), center = c + Offset(0f, 3.dp.toPx()))
        }
        drawCircle(Color.White, radius = face, center = c)
        drawCircle(Color(0xFFE8E8E8), radius = face, center = c, style = Stroke(2.dp.toPx()))

        fun dir(deg: Float): Offset {
            val a = Math.toRadians(deg - 90.0)
            return Offset(cos(a).toFloat(), sin(a).toFloat())
        }
        for (i in 0 until 4) {
            val d = dir(i * 90f)
            drawLine(Color(0xFF9A9A9A), c + d * (face * 0.82f), c + d * (face * 0.92f), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
        }
        val h = (time.hour % 12 + time.minute / 60f + time.second / 3600f) * 30f
        val m = (time.minute + time.second / 60f) * 6f
        val s = time.second * 6f
        drawLine(Color.Black, c - dir(h) * (face * 0.08f), c + dir(h) * (face * 0.5f), strokeWidth = 6.dp.toPx(), cap = StrokeCap.Round)
        drawLine(Color.Black, c - dir(m) * (face * 0.08f), c + dir(m) * (face * 0.74f), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
        drawLine(Color(0xFFE53935), c - dir(s) * (face * 0.16f), c + dir(s) * (face * 0.82f), strokeWidth = 1.5f.dp.toPx(), cap = StrokeCap.Round)
        drawCircle(Color.Black, radius = 6.dp.toPx(), center = c)
    }
}
