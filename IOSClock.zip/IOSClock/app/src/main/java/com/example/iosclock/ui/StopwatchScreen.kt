package com.example.iosclock.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.iosclock.ClockViewModel
import kotlinx.coroutines.delay

private val tabular = TextStyle(fontFeatureSettings = "tnum")

@Composable
fun StopwatchScreen(vm: ClockViewModel) {
    var elapsed by remember { mutableLongStateOf(vm.swElapsed()) }
    LaunchedEffect(vm.swRunning, vm.swBase) {
        elapsed = vm.swElapsed()
        while (vm.swRunning) {
            elapsed = vm.swElapsed()
            delay(16)
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            "Stopwatch",
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier.align(Alignment.Start).padding(top = 56.dp),
        )
        Spacer(Modifier.height(24.dp))
        Text(
            formatStopwatch(elapsed),
            style = tabular,
            color = Color.White,
            fontSize = 76.sp,
            fontWeight = FontWeight.Thin,
            maxLines = 1,
        )
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            if (vm.swRunning) {
                RoundButton("Lap", Color.White, CardBg2) { vm.swLap() }
                RoundButton("Stop", IosRed, IosRed.copy(alpha = 0.25f)) { vm.swToggle() }
            } else {
                RoundButton("Reset", Color.White, CardBg2, enabled = elapsed > 0L) { vm.swReset() }
                RoundButton("Start", IosGreen, IosGreen.copy(alpha = 0.25f)) { vm.swToggle() }
            }
        }
        Spacer(Modifier.height(16.dp))
        HorizontalDivider(color = CardBg2)

        val lastCum = vm.laps.lastOrNull() ?: 0L
        LazyColumn(Modifier.fillMaxWidth()) {
            if (elapsed > 0L) {
                item { LapRow("Lap ${vm.laps.size + 1}", elapsed - lastCum) }
            }
            itemsIndexed(vm.laps.reversed()) { reversedIndex, cumulative ->
                val i = vm.laps.size - 1 - reversedIndex
                val previous = if (i > 0) vm.laps[i - 1] else 0L
                LapRow("Lap ${i + 1}", cumulative - previous)
            }
        }
    }
}

@Composable
private fun LapRow(label: String, ms: Long) {
    Column {
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color.White, fontSize = 17.sp)
            Text(formatStopwatch(ms), color = Color.White, fontSize = 17.sp, style = tabular)
        }
        HorizontalDivider(color = CardBg2)
    }
}
