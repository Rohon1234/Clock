package com.example.iosclock.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.iosclock.ClockViewModel
import kotlinx.coroutines.delay

@Composable
fun StopwatchScreen(vm: ClockViewModel) {
    AlarmTheme {
        Box(Modifier.fillMaxSize().background(PageBg)) {
            if (vm.swSettings) SettingsPage { vm.swSettings = false } else StopwatchMain(vm)
        }
    }
}

private fun lapNumber(i: Int): String = i.toString().padStart(2, '0')

@Composable
private fun StopwatchMain(vm: ClockViewModel) {
    var el by remember { mutableLongStateOf(vm.swElapsed()) }
    LaunchedEffect(Unit) {
        while (true) {
            if (vm.swRunning) withFrameMillis { } else delay(100)
            el = vm.swElapsed()
        }
    }
    val laps = vm.laps.toList()
    val big = laps.isEmpty()
    val ringSize = if (big) 290.dp else 220.dp
    val lastLap = laps.lastOrNull() ?: 0L

    Column(Modifier.fillMaxSize()) {
        PageTitleBar("Stopwatch") { SettingsMenuButton { vm.swSettings = true } }

        Box(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 8.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(ringSize), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 14.dp.toPx()
                    val topLeft = Offset(stroke / 2f, stroke / 2f)
                    val arcSize = Size(size.width - stroke, size.height - stroke)
                    drawArc(RingTrack, 0f, 360f, false, topLeft, arcSize, style = Stroke(stroke))
                    val sweep = ((el % 60_000L).toFloat() / 60_000f) * 360f
                    if (el > 0L && sweep > 0f) {
                        drawArc(ClockBlue, -90f, sweep, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                    }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        formatStopwatch(el),
                        color = Color.Black,
                        style = TextStyle(
                            fontSize = if (big) 50.sp else 40.sp,
                            fontWeight = FontWeight.Bold,
                            fontFeatureSettings = "tnum",
                        ),
                    )
                    Text(
                        "+" + formatStopwatch((el - lastLap).coerceAtLeast(0L)),
                        color = Gray99,
                        style = TextStyle(fontSize = 18.sp, fontFeatureSettings = "tnum"),
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
            }
        }

        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(laps.indices.reversed().toList(), key = { it }) { i ->
                val total = laps[i]
                val split = total - if (i > 0) laps[i - 1] else 0L
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(lapNumber(i + 1), color = Gray99, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    Text(
                        "+" + formatStopwatch(split),
                        color = Gray99,
                        style = TextStyle(fontSize = 16.sp, fontFeatureSettings = "tnum"),
                        modifier = Modifier.weight(2f),
                    )
                    Text(
                        formatStopwatch(total),
                        color = Color.Black,
                        style = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.Bold, fontFeatureSettings = "tnum"),
                    )
                }
            }
        }

        ControlsRow(
            left = { GrayIconButton(Icons.Filled.Refresh, "Reset", enabled = !vm.swRunning && el > 0L) { vm.swReset() } },
            center = { BluePlayButton(playing = vm.swRunning) { vm.swToggle() } },
            right = { GrayIconButton(Icons.Filled.Flag, "Lap", enabled = vm.swRunning) { vm.swLap() } },
        )
    }
}
