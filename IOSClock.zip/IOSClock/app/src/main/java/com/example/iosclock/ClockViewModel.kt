package com.example.iosclock

import android.app.Application
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.example.iosclock.alarm.Alarm
import com.example.iosclock.alarm.AlarmScheduler
import com.example.iosclock.alarm.AlarmStore
import com.example.iosclock.alarm.ZoneStore

class ClockViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Application get() = getApplication()

    // ---------- World clock ----------
    val zones = mutableStateListOf<String>().apply { addAll(ZoneStore.load(app)) }

    fun addZone(id: String) {
        if (id !in zones) {
            zones.add(id)
            ZoneStore.save(ctx, zones)
        }
    }

    fun removeZone(id: String) {
        zones.remove(id)
        ZoneStore.save(ctx, zones)
    }

    // ---------- Alarms ----------
    val alarms = mutableStateListOf<Alarm>().apply { addAll(sorted(AlarmStore.load(app))) }

    private fun sorted(list: List<Alarm>) = list.sortedWith(compareBy({ it.hour }, { it.minute }))

    fun reloadAlarms() {
        val fresh = sorted(AlarmStore.load(ctx))
        alarms.clear()
        alarms.addAll(fresh)
    }

    fun newAlarm(): Alarm = Alarm(
        id = (alarms.maxOfOrNull { it.id } ?: 0) + 1,
        hour = 7,
        minute = 0,
    )

    fun saveAlarm(a: Alarm) {
        val i = alarms.indexOfFirst { it.id == a.id }
        if (i >= 0) alarms[i] = a else alarms.add(a)
        val ordered = sorted(alarms.toList())
        alarms.clear()
        alarms.addAll(ordered)
        AlarmStore.save(ctx, alarms)
        if (a.enabled) AlarmScheduler.schedule(ctx, a) else AlarmScheduler.cancel(ctx, a.id)
    }

    fun toggleAlarm(a: Alarm) = saveAlarm(a.copy(enabled = !a.enabled))

    fun deleteAlarm(a: Alarm) {
        alarms.removeAll { it.id == a.id }
        AlarmStore.save(ctx, alarms)
        AlarmScheduler.cancel(ctx, a.id)
    }

    // ---------- Stopwatch ----------
    var swRunning by mutableStateOf(false)
        private set
    var swBase by mutableLongStateOf(0L)
        private set
    private var swStartedAt = 0L
    val laps = mutableStateListOf<Long>()

    fun swElapsed(): Long =
        if (swRunning) swBase + SystemClock.elapsedRealtime() - swStartedAt else swBase

    fun swToggle() {
        if (swRunning) {
            swBase = swElapsed()
            swRunning = false
        } else {
            swStartedAt = SystemClock.elapsedRealtime()
            swRunning = true
        }
    }

    fun swLap() {
        if (swRunning) laps.add(swElapsed())
    }

    fun swReset() {
        swRunning = false
        swBase = 0L
        laps.clear()
    }

    // ---------- Timer ----------
    var tmH by mutableIntStateOf(0)
    var tmM by mutableIntStateOf(1)
    var tmS by mutableIntStateOf(0)
    var tmActive by mutableStateOf(false)
        private set
    var tmRunning by mutableStateOf(false)
        private set
    var tmTotal by mutableLongStateOf(0L)
        private set
    private var tmEndAt = 0L
    private var tmRemaining = 0L

    fun tmRemainingNow(): Long =
        if (tmRunning) maxOf(0L, tmEndAt - SystemClock.elapsedRealtime()) else tmRemaining

    fun tmStart() {
        val total = ((tmH * 60L + tmM) * 60L + tmS) * 1000L
        if (total <= 0L) return
        tmTotal = total
        tmRemaining = total
        tmActive = true
        tmResume()
    }

    fun tmResume() {
        tmEndAt = SystemClock.elapsedRealtime() + tmRemaining
        tmRunning = true
        AlarmScheduler.scheduleTimer(ctx, System.currentTimeMillis() + tmRemaining)
    }

    fun tmPause() {
        tmRemaining = tmRemainingNow()
        tmRunning = false
        AlarmScheduler.cancelTimer(ctx)
    }

    fun tmCancel() {
        tmRunning = false
        tmActive = false
        AlarmScheduler.cancelTimer(ctx)
    }

    /** Called by the UI loop; the AlarmManager alarm rings even if the app is closed. */
    fun tmCheckFinished() {
        if (tmRunning && tmRemainingNow() <= 0L) {
            tmRunning = false
            tmActive = false
        }
    }
}
