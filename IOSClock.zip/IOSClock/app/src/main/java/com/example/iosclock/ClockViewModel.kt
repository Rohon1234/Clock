package com.example.iosclock

import android.app.Application
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.example.iosclock.alarm.Alarm
import com.example.iosclock.alarm.AlarmScheduler
import com.example.iosclock.alarm.AlarmStore
import com.example.iosclock.alarm.TimerPreset
import com.example.iosclock.alarm.TimerStore
import com.example.iosclock.alarm.ZoneStore
import java.time.LocalTime

/** The pages inside the Alarm tab. */
enum class AlarmRoute { LIST, EDIT, SOUND, SNOOZE, SETTINGS }
enum class WorldRoute { MAIN, ADD, SETTINGS }
enum class TimerRoute { MAIN, EDIT, SOUND, SETTINGS }

class ClockViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Application get() = getApplication()

    // ---------- World clock ----------
    val zones = mutableStateListOf<String>().apply { addAll(ZoneStore.load(app)) }

    fun addZone(id: String) {
        if (id !in zones) {
            zones.add(id)
            ZoneStore.save(ctx, zones)
        }
    }

    fun removeZones(ids: Set<String>) {
        zones.removeAll { it in ids }
        ZoneStore.save(ctx, zones)
    }

    fun moveZone(from: Int, to: Int) {
        if (from in zones.indices && to in zones.indices) zones.add(to, zones.removeAt(from))
    }

    fun saveZones() = ZoneStore.save(ctx, zones)

    var worldRoute by mutableStateOf(WorldRoute.MAIN)
    var worldSelecting by mutableStateOf(false)

    // ---------- Alarms ----------
    val alarms = mutableStateListOf<Alarm>().apply { addAll(sorted(AlarmStore.load(app))) }

    var alarmRoute by mutableStateOf(AlarmRoute.LIST)

    /** The alarm being created or edited on the Add Alarm page and its sub pages. */
    var draft by mutableStateOf<Alarm?>(null)
    var draftIsNew by mutableStateOf(false)

    private fun sorted(list: List<Alarm>) = list.sortedWith(compareBy({ it.hour }, { it.minute }))

    fun reloadAlarms() {
        val fresh = sorted(AlarmStore.load(ctx))
        alarms.clear()
        alarms.addAll(fresh)
    }

    private fun nextId(): Int = (alarms.maxOfOrNull { it.id } ?: 0) + 1

    fun startNew() {
        val now = LocalTime.now()
        draft = Alarm(id = nextId(), hour = now.hour, minute = now.minute)
        draftIsNew = true
        alarmRoute = AlarmRoute.EDIT
    }

    fun startEdit(a: Alarm) {
        draft = a
        draftIsNew = false
        alarmRoute = AlarmRoute.EDIT
    }

    fun commitDraft() {
        draft?.let { saveAlarm(it.copy(enabled = true)) }
        draft = null
        alarmRoute = AlarmRoute.LIST
    }

    fun alarmBack() {
        when (alarmRoute) {
            AlarmRoute.EDIT -> {
                draft = null
                alarmRoute = AlarmRoute.LIST
            }
            AlarmRoute.SOUND, AlarmRoute.SNOOZE -> alarmRoute = AlarmRoute.EDIT
            AlarmRoute.SETTINGS -> alarmRoute = AlarmRoute.LIST
            AlarmRoute.LIST -> Unit
        }
    }

    fun saveAlarm(a: Alarm) {
        val i = alarms.indexOfFirst { it.id == a.id }
        if (i >= 0) alarms[i] = a else alarms.add(a)
        val ordered = sorted(alarms.toList())
        alarms.clear()
        alarms.addAll(ordered)
        AlarmStore.save(ctx, alarms)
        if (a.enabled) AlarmScheduler.schedule(ctx, a) else AlarmScheduler.cancel(ctx, a.id)
    }

    fun toggleAlarm(a: Alarm) = saveAlarm(a.copy(enabled = !a.enabled))

    fun deleteAlarm(a: Alarm) {
        alarms.removeAll { it.id == a.id }
        AlarmStore.save(ctx, alarms)
        AlarmScheduler.cancel(ctx, a.id)
    }

    // ---------- Stopwatch ----------
    var swRunning by mutableStateOf(false)
        private set
    var swBase by mutableLongStateOf(0L)
        private set
    private var swStartedAt = 0L
    val laps = mutableStateListOf<Long>()
    var swSettings by mutableStateOf(false)

    fun swElapsed(): Long =
        if (swRunning) swBase + SystemClock.elapsedRealtime() - swStartedAt else swBase

    fun swToggle() {
        if (swRunning) {
            swBase = swElapsed()
            swRunning = false
        } else {
            swStartedAt = SystemClock.elapsedRealtime()
            swRunning = true
        }
    }

    fun swLap() {
        if (swRunning) laps.add(swElapsed())
    }

    fun swReset() {
        swRunning = false
        swBase = 0L
        laps.clear()
    }

    // ---------- Timer ----------
    var tmH by mutableIntStateOf(0)
    var tmM by mutableIntStateOf(20)
    var tmS by mutableIntStateOf(0)
    var tmActive by mutableStateOf(false)
        private set
    var tmRunning by mutableStateOf(false)
        private set
    var tmTotal by mutableLongStateOf(0L)
        private set
    private var tmEndAt = 0L
    private var tmRemaining = 0L

    val presets = mutableStateListOf<TimerPreset>().apply { addAll(TimerStore.load(app)) }
    var timerRoute by mutableStateOf(TimerRoute.MAIN)
    var tmDraft by mutableStateOf<TimerPreset?>(null)
    var tmDraftIsNew by mutableStateOf(false)
    var tmSound by mutableStateOf(TimerStore.sound(app))
    var pickerVersion by mutableIntStateOf(0)

    fun setTimerSound(key: String) {
        tmSound = key
        TimerStore.setSound(ctx, key)
    }

    fun tmStartNew() {
        tmDraft = TimerPreset((presets.maxOfOrNull { it.id } ?: 0) + 1, "Timer", 0, "TIMER", true)
        tmDraftIsNew = true
        timerRoute = TimerRoute.EDIT
    }

    fun tmStartEdit(p: TimerPreset) {
        tmDraft = p
        tmDraftIsNew = false
        timerRoute = TimerRoute.EDIT
    }

    fun tmCommit(p: TimerPreset) {
        val i = presets.indexOfFirst { it.id == p.id }
        if (i >= 0) presets[i] = p else presets.add(p)
        TimerStore.save(ctx, presets)
        tmDraft = null
        timerRoute = TimerRoute.MAIN
    }

    fun tmDeletePreset(p: TimerPreset) {
        presets.removeAll { it.id == p.id }
        TimerStore.save(ctx, presets)
    }

    fun tmBack() {
        when (timerRoute) {
            TimerRoute.EDIT -> {
                tmDraft = null
                timerRoute = TimerRoute.MAIN
            }
            TimerRoute.SOUND, TimerRoute.SETTINGS -> timerRoute = TimerRoute.MAIN
            TimerRoute.MAIN -> Unit
        }
    }

    fun tmPick(p: TimerPreset) {
        tmH = p.seconds / 3600
        tmM = (p.seconds / 60) % 60
        tmS = p.seconds % 60
        pickerVersion++
    }

    /** Back to the full duration, paused. Pressing it again leaves the running screen. */
    fun tmReset() {
        if (!tmRunning && tmRemaining == tmTotal) {
            tmCancel()
            return
        }
        tmRunning = false
        tmRemaining = tmTotal
        AlarmScheduler.cancelTimer(ctx)
    }

    fun tmRemainingNow(): Long =
        if (tmRunning) maxOf(0L, tmEndAt - SystemClock.elapsedRealtime()) else tmRemaining

    fun tmStart() {
        val total = ((tmH * 60L + tmM) * 60L + tmS) * 1000L
        if (total <= 0L) return
        tmTotal = total
        tmRemaining = total
        tmActive = true
        tmResume()
    }

    fun tmResume() {
        tmEndAt = SystemClock.elapsedRealtime() + tmRemaining
        tmRunning = true
        AlarmScheduler.scheduleTimer(ctx, System.currentTimeMillis() + tmRemaining)
    }

    fun tmPause() {
        tmRemaining = tmRemainingNow()
        tmRunning = false
        AlarmScheduler.cancelTimer(ctx)
    }

    fun tmCancel() {
        tmRunning = false
        tmActive = false
        AlarmScheduler.cancelTimer(ctx)
    }

    /** Called by the UI loop; the AlarmManager alarm rings even if the app is closed. */
    fun tmCheckFinished() {
        if (tmRunning && tmRemainingNow() <= 0L) {
            tmRunning = false
            tmActive = false
        }
    }
}
