package com.example.iosclock.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.example.iosclock.MainActivity
import java.time.ZonedDateTime

object AlarmScheduler {
    const val TIMER_ID = -1
    const val EXTRA_ID = "alarm_id"
    const val EXTRA_SNOOZE = "alarm_snooze"
    const val ACTION_SNOOZE = "com.example.iosclock.ACTION_SNOOZE"
    const val ACTION_STOP = "com.example.iosclock.ACTION_STOP"
    private const val SNOOZE_BASE = 100_000

    fun nextTrigger(a: Alarm, now: ZonedDateTime = ZonedDateTime.now()): ZonedDateTime {
        for (d in 0L..7L) {
            val c = now.toLocalDate().plusDays(d).atTime(a.hour, a.minute).atZone(now.zone)
            if (c.isAfter(now) && (a.days.isEmpty() || c.dayOfWeek.value in a.days)) return c
        }
        return now.plusDays(1)
    }

    private const val FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    private fun ringPending(ctx: Context, id: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, id,
            Intent(ctx, AlarmReceiver::class.java).putExtra(EXTRA_ID, id),
            FLAGS,
        )

    private fun snoozePending(ctx: Context, id: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, SNOOZE_BASE + id,
            Intent(ctx, AlarmReceiver::class.java).putExtra(EXTRA_ID, id).putExtra(EXTRA_SNOOZE, true),
            FLAGS,
        )

    private fun setClock(ctx: Context, triggerAtMillis: Long, pending: PendingIntent) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val show = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAtMillis, show), pending)
    }

    fun schedule(ctx: Context, a: Alarm) =
        setClock(ctx, nextTrigger(a).toInstant().toEpochMilli(), ringPending(ctx, a.id))

    fun cancel(ctx: Context, id: Int) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(ringPending(ctx, id))
        am.cancel(snoozePending(ctx, id))
    }

    fun scheduleSnooze(ctx: Context, id: Int, atMillis: Long) =
        setClock(ctx, atMillis, snoozePending(ctx, id))

    fun cancelSnooze(ctx: Context, id: Int) {
        ctx.getSystemService(AlarmManager::class.java).cancel(snoozePending(ctx, id))
    }

    fun scheduleTimer(ctx: Context, atMillis: Long) =
        setClock(ctx, atMillis, ringPending(ctx, TIMER_ID))

    fun cancelTimer(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(ringPending(ctx, TIMER_ID))
    }

    fun rescheduleAll(ctx: Context) {
        AlarmStore.load(ctx).filter { it.enabled }.forEach { schedule(ctx, it) }
    }
}
