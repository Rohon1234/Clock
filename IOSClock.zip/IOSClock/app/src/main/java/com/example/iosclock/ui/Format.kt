package com.example.iosclock.ui

import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs

private fun f(fmt: String, vararg a: Any) = String.format(Locale.US, fmt, *a)

fun cityName(zoneId: String) = zoneId.substringAfterLast('/').replace('_', ' ')

fun regionName(zoneId: String) = zoneId.substringBefore('/').replace('_', ' ')

fun dayLabel(now: LocalDate, other: LocalDate): String = when {
    other.isAfter(now) -> "Tomorrow"
    other.isBefore(now) -> "Yesterday"
    else -> "Today"
}

fun offsetLabel(diffSeconds: Int): String {
    val sign = if (diffSeconds >= 0) "+" else "-"
    val a = abs(diffSeconds)
    val h = a / 3600
    val m = (a % 3600) / 60
    return if (m == 0) "$sign${h}HRS" else f("%s%d:%02dHRS", sign, h, m)
}

fun formatStopwatch(ms: Long): String {
    val total = ms / 10
    val cs = total % 100
    val s = (total / 100) % 60
    val m = (total / 6000) % 60
    val h = total / 360000
    return if (h > 0) f("%d:%02d:%02d.%02d", h, m, s, cs) else f("%02d:%02d.%02d", m, s, cs)
}

fun formatCountdown(ms: Long): String {
    val secs = (ms + 999) / 1000
    val h = secs / 3600
    val m = (secs / 60) % 60
    val s = secs % 60
    return if (h > 0) f("%d:%02d:%02d", h, m, s) else f("%02d:%02d", m, s)
}

/** Returns the clock text and the AM/PM suffix (empty in 24-hour mode). */
fun timeParts(t: LocalTime, is24: Boolean): Pair<String, String> =
    if (is24) DateTimeFormatter.ofPattern("HH:mm").format(t) to ""
    else DateTimeFormatter.ofPattern("h:mm").format(t) to DateTimeFormatter.ofPattern("a").format(t)

@Composable
fun is24Hour(): Boolean = DateFormat.is24HourFormat(androidx.compose.ui.platform.LocalContext.current)

@Composable
fun RoundButton(
    label: String,
    fg: Color,
    bg: Color,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Box(
        Modifier
            .size(92.dp)
            .clip(CircleShape)
            .background(bg)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (enabled) fg else Subtle, fontSize = 18.sp, fontWeight = FontWeight.Medium)
    }
}
