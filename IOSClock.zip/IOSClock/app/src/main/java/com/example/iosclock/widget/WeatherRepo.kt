package com.example.iosclock.widget

import android.content.BroadcastReceiver
import android.content.Context
import com.example.iosclock.R
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Temperature for the widgets, from the free Open-Meteo service (no account or key).
 * The city is the one chosen for the widget (the phone's own time zone by default).
 * Results are cached, so the network is touched at most once every 30 minutes.
 */
object WeatherRepo {
    data class Wx(val tempC: Int, val icon: Int)

    private const val PREFS = "clock_prefs"
    private const val FRESH_MS = 30 * 60 * 1000L
    private const val RETRY_MS = 10 * 60 * 1000L

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun cached(ctx: Context, zone: String): Wx? {
        val raw = prefs(ctx).getString("wx_$zone", null) ?: return null
        return try {
            val p = raw.split(",")
            Wx(p[0].toInt(), iconFor(p[1].toInt(), p[2] == "1"))
        } catch (e: Exception) {
            null
        }
    }

    private fun iconFor(code: Int, day: Boolean): Int = when {
        code <= 1 -> if (day) R.drawable.ic_wx_sun else R.drawable.ic_wx_moon
        code in 51..67 || code in 80..82 -> R.drawable.ic_wx_rain
        code in 71..77 || code == 85 || code == 86 -> R.drawable.ic_wx_snow
        code >= 95 -> R.drawable.ic_wx_storm
        else -> R.drawable.ic_wx_cloud
    }

    /** Refreshes stale temperatures on a background thread, then redraws the widgets. */
    fun refreshAsync(ctx: Context, pending: BroadcastReceiver.PendingResult?) {
        val app = ctx.applicationContext
        Thread {
            try {
                if (refreshStale(app)) SecondsWidgets.updateAll(app)
            } catch (e: Exception) {
                // keep showing the cached value
            } finally {
                pending?.finish()
            }
        }.start()
    }

    private fun refreshStale(ctx: Context): Boolean {
        val now = System.currentTimeMillis()
        var changed = false
        for (zone in SecondsWidgets.activeZones(ctx)) {
            val ts = prefs(ctx).getString("wx_$zone", null)?.split(",")?.getOrNull(3)?.toLongOrNull() ?: 0L
            val tried = prefs(ctx).getLong("wx_try_$zone", 0L)
            if (now - ts < FRESH_MS || now - tried < RETRY_MS) continue
            prefs(ctx).edit().putLong("wx_try_$zone", now).apply()
            if (fetch(ctx, zone)) changed = true
        }
        return changed
    }

    private fun fetch(ctx: Context, zone: String): Boolean {
        val (lat, lon) = location(ctx, zone) ?: return false
        val body = httpGet(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,weather_code,is_day&timezone=auto"
        ) ?: return false
        val cur = JSONObject(body).getJSONObject("current")
        val temp = Math.round(cur.getDouble("temperature_2m")).toInt()
        val code = cur.getInt("weather_code")
        val day = cur.getInt("is_day")
        prefs(ctx).edit().putString("wx_$zone", "$temp,$code,$day,${System.currentTimeMillis()}").apply()
        return true
    }

    private fun location(ctx: Context, zone: String): Pair<Double, Double>? {
        prefs(ctx).getString("geo_$zone", null)?.split(",")?.let {
            if (it.size == 2) return Pair(it[0].toDouble(), it[1].toDouble())
        }
        val city = zone.substringAfterLast('/').replace('_', ' ')
        val body = httpGet(
            "https://geocoding-api.open-meteo.com/v1/search?name=${URLEncoder.encode(city, "UTF-8")}" +
                "&count=1&language=en&format=json"
        ) ?: return null
        val results = JSONObject(body).optJSONArray("results") ?: return null
        if (results.length() == 0) return null
        val first = results.getJSONObject(0)
        val lat = first.getDouble("latitude")
        val lon = first.getDouble("longitude")
        prefs(ctx).edit().putString("geo_$zone", "$lat,$lon").apply()
        return Pair(lat, lon)
    }

    private fun httpGet(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = 6000
            c.readTimeout = 6000
            if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
        } catch (e: Exception) {
            null
        } finally {
            c.disconnect()
        }
    }
}
