package com.example.iosclock

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.iosclock.ui.AlarmColors
import com.example.iosclock.ui.AlarmScreen
import com.example.iosclock.ui.CardBg
import com.example.iosclock.ui.IOSClockTheme
import com.example.iosclock.ui.Orange
import com.example.iosclock.ui.StopwatchScreen
import com.example.iosclock.ui.Subtle
import com.example.iosclock.ui.TimerScreen
import com.example.iosclock.ui.WorldClockScreen

class MainActivity : ComponentActivity() {
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { IOSClockTheme { ClockApp() } }
    }
}

/** Same order as the reference screens: Alarm, World Clock, Timer, Stopwatch. */
private enum class Tab(val title: String, val icon: ImageVector) {
    ALARM("Alarm", Icons.Filled.Alarm),
    WORLD("World Clock", Icons.Filled.Public),
    TIMER("Timer", Icons.Filled.HourglassBottom),
    STOPWATCH("Stopwatch", Icons.Filled.Timer),
}

@Composable
private fun ClockApp() {
    val vm: ClockViewModel = viewModel()
    var tab by rememberSaveable { mutableStateOf(Tab.ALARM) }

    // The Alarm tab is light; the other tabs keep their dark look until they are updated.
    val light = tab == Tab.ALARM
    val showNav = !(tab == Tab.ALARM && vm.alarmRoute != AlarmRoute.LIST)

    // A one-time alarm turns itself off when it rings, so refresh the list when the app is shown.
    LifecycleResumeEffect(Unit) {
        vm.reloadAlarms()
        onPauseOrDispose { }
    }

    BackHandler(enabled = tab == Tab.ALARM && vm.alarmRoute != AlarmRoute.LIST) { vm.alarmBack() }

    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window
        if (window != null) {
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = light
            controller.isAppearanceLightNavigationBars = light
        }
    }

    Scaffold(
        containerColor = if (light) Color.White else Color.Black,
        bottomBar = {
            if (showNav) {
                NavigationBar(containerColor = if (light) Color.White else CardBg) {
                    Tab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { tab = t },
                            icon = { Icon(t.icon, contentDescription = t.title) },
                            label = { Text(t.title, fontSize = 11.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = if (light) AlarmColors.Blue else Orange,
                                selectedTextColor = if (light) AlarmColors.Blue else Orange,
                                indicatorColor = Color.Transparent,
                                unselectedIconColor = if (light) AlarmColors.Gray else Subtle,
                                unselectedTextColor = if (light) AlarmColors.Gray else Subtle,
                            ),
                        )
                    }
                }
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (tab) {
                Tab.ALARM -> AlarmScreen(vm)
                Tab.WORLD -> WorldClockScreen(vm)
                Tab.TIMER -> TimerScreen(vm)
                Tab.STOPWATCH -> StopwatchScreen(vm)
            }
        }
    }
}
