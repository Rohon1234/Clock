package com.example.iosclock

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.iosclock.ui.AlarmScreen
import com.example.iosclock.ui.CardBg
import com.example.iosclock.ui.IOSClockTheme
import com.example.iosclock.ui.Orange
import com.example.iosclock.ui.StopwatchScreen
import com.example.iosclock.ui.Subtle
import com.example.iosclock.ui.TimerScreen
import com.example.iosclock.ui.WorldClockScreen

class MainActivity : ComponentActivity() {
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { IOSClockTheme { ClockApp() } }
    }
}

private enum class Tab(val title: String, val icon: ImageVector) {
    WORLD("World Clock", Icons.Filled.Public),
    ALARM("Alarm", Icons.Filled.Alarm),
    STOPWATCH("Stopwatch", Icons.Filled.Timer),
    TIMER("Timer", Icons.Filled.HourglassBottom),
}

@Composable
private fun ClockApp() {
    val vm: ClockViewModel = viewModel()
    var tab by rememberSaveable { mutableStateOf(Tab.WORLD) }

    // A one-time alarm turns itself off when it rings, so refresh the list when the app is shown.
    LifecycleResumeEffect(Unit) {
        vm.reloadAlarms()
        onPauseOrDispose { }
    }

    Scaffold(
        containerColor = Color.Black,
        bottomBar = {
            NavigationBar(containerColor = CardBg) {
                Tab.entries.forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = { Icon(t.icon, contentDescription = t.title) },
                        label = { Text(t.title, fontSize = 11.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Orange,
                            selectedTextColor = Orange,
                            indicatorColor = Color.Transparent,
                            unselectedIconColor = Subtle,
                            unselectedTextColor = Subtle,
                        ),
                    )
                }
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (tab) {
                Tab.WORLD -> WorldClockScreen(vm)
                Tab.ALARM -> AlarmScreen(vm)
                Tab.STOPWATCH -> StopwatchScreen(vm)
                Tab.TIMER -> TimerScreen(vm)
            }
        }
    }
}
