package com.example.iosclock.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.iosclock.MainActivity
import com.example.iosclock.R

/** The clock faces tick on their own (TextClock / AnalogClock), so we only wire up the tap action. */
abstract class BaseClockWidget(private val layoutRes: Int) : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        appWidgetIds.forEach { id ->
            val views = RemoteViews(context.packageName, layoutRes)
            views.setOnClickPendingIntent(R.id.widget_root, open)
            manager.updateAppWidget(id, views)
        }
    }
}

class DigitalClockWidget : BaseClockWidget(R.layout.widget_digital)

class AnalogClockWidget : BaseClockWidget(R.layout.widget_analog)
