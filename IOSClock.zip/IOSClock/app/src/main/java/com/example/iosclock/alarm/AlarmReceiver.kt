package com.example.iosclock.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.LocalTime
import java.time.format.DateTimeFormatter

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra(AlarmScheduler.EXTRA_ID, Int.MIN_VALUE)
        if (id == AlarmScheduler.TIMER_ID) {
            Notifications.show(context, Notifications.TIMER_NOTIFICATION_ID, "Timer", "Time's up")
            return
        }
        val alarm = AlarmStore.load(context).firstOrNull { it.id == id } ?: return
        val time = LocalTime.of(alarm.hour, alarm.minute)
            .format(DateTimeFormatter.ofLocalizedTime(java.time.format.FormatStyle.SHORT))
        Notifications.show(context, alarm.id, alarm.label.ifBlank { "Alarm" }, time)
        if (alarm.days.isEmpty()) {
            AlarmStore.update(context, alarm.copy(enabled = false))
        } else {
            AlarmScheduler.schedule(context, alarm)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AlarmScheduler.rescheduleAll(context)
        com.example.iosclock.widget.SecondsWidgets.refresh(context)
    }
}
