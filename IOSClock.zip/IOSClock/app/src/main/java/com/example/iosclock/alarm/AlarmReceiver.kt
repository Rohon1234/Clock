package com.example.iosclock.alarm

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra(AlarmScheduler.EXTRA_ID, Int.MIN_VALUE)
        when (intent.action) {
            AlarmScheduler.ACTION_SNOOZE -> snooze(context, id)
            AlarmScheduler.ACTION_STOP -> stop(context, id)
            else -> ring(context, id, intent.getBooleanExtra(AlarmScheduler.EXTRA_SNOOZE, false))
        }
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("clock_prefs", Context.MODE_PRIVATE)

    private fun ring(context: Context, id: Int, isSnooze: Boolean) {
        if (id == AlarmScheduler.TIMER_ID) {
            Notifications.show(context, Notifications.TIMER_NOTIFICATION_ID, "Timer", "Time's up")
            return
        }
        val alarm = AlarmStore.load(context).firstOrNull { it.id == id } ?: return
        if (!isSnooze) {
            prefs(context).edit().putInt("snz_$id", 0).apply()
            if (alarm.days.isEmpty()) {
                // One-time alarm: switch it off now. "Delete after ringing" removes it when it is stopped.
                AlarmStore.update(context, alarm.copy(enabled = false))
            } else {
                AlarmScheduler.schedule(context, alarm)
            }
        }
        val used = prefs(context).getInt("snz_$id", 0)
        val text = LocalTime.of(alarm.hour, alarm.minute)
            .format(DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH))
        Notifications.showAlarm(context, alarm, text, alarm.snoozeTimes > 0 && used < alarm.snoozeTimes)
    }

    private fun snooze(context: Context, id: Int) {
        context.getSystemService(NotificationManager::class.java).cancel(id)
        val alarm = AlarmStore.load(context).firstOrNull { it.id == id } ?: return
        val used = prefs(context).getInt("snz_$id", 0)
        if (used < alarm.snoozeTimes) {
            prefs(context).edit().putInt("snz_$id", used + 1).apply()
            AlarmScheduler.scheduleSnooze(context, id, System.currentTimeMillis() + alarm.snoozeMinutes * 60_000L)
        } else {
            finishAlarm(context, alarm)
        }
    }

    private fun stop(context: Context, id: Int) {
        context.getSystemService(NotificationManager::class.java).cancel(id)
        AlarmScheduler.cancelSnooze(context, id)
        val alarm = AlarmStore.load(context).firstOrNull { it.id == id } ?: return
        finishAlarm(context, alarm)
    }

    private fun finishAlarm(context: Context, alarm: Alarm) {
        if (alarm.deleteAfterRinging && alarm.days.isEmpty()) AlarmStore.remove(context, alarm.id)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AlarmScheduler.rescheduleAll(context)
        com.example.iosclock.widget.SecondsWidgets.refresh(context)
    }
}
