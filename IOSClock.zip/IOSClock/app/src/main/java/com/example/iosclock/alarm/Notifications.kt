package com.example.iosclock.alarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import com.example.iosclock.MainActivity
import com.example.iosclock.R

object Notifications {
    const val TIMER_NOTIFICATION_ID = 1_000_000

    /** One channel per (sound, vibrate) pair, because Android fixes a channel's sound once it exists. */
    private fun channelFor(ctx: Context, soundKey: String, vibrate: Boolean): String {
        val id = "alarm_${soundKey.hashCode()}_${if (vibrate) "v" else "n"}"
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(id) == null) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val channel = NotificationChannel(id, "Alarm (${Sounds.label(ctx, soundKey)})", NotificationManager.IMPORTANCE_HIGH)
            val uri = Sounds.resolveUri(soundKey)
            if (uri == null) channel.setSound(null, null) else channel.setSound(uri, attrs)
            channel.enableVibration(vibrate)
            if (vibrate) channel.vibrationPattern = longArrayOf(0, 500, 300, 500)
            channel.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(channel)
        }
        return id
    }

    private fun openIntent(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    private fun actionIntent(ctx: Context, id: Int, action: String, code: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, id * 10 + code,
            Intent(ctx, AlarmReceiver::class.java).setAction(action).putExtra(AlarmScheduler.EXTRA_ID, id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    private fun finish(notification: Notification, ctx: Context, notificationId: Int) {
        // Keep ringing until the user dismisses it.
        notification.flags = notification.flags or Notification.FLAG_INSISTENT
        ctx.getSystemService(NotificationManager::class.java).notify(notificationId, notification)
    }

    /** Used by the timer. */
    fun show(ctx: Context, notificationId: Int, title: String, text: String, soundKey: String = SOUND_DEFAULT) {
        val open = openIntent(ctx)
        val notification = Notification.Builder(ctx, channelFor(ctx, soundKey, true))
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .setAutoCancel(true)
            .build()
        finish(notification, ctx, notificationId)
    }

    fun showAlarm(ctx: Context, alarm: Alarm, timeText: String, canSnooze: Boolean) {
        val open = openIntent(ctx)
        val uri = Sounds.resolveUri(alarm.sound)
        if (uri != null && uri.scheme == "content") {
            try {
                ctx.grantUriPermission("com.android.systemui", uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // the sound may still play if the system can already read it
            }
        }
        val builder = Notification.Builder(ctx, channelFor(ctx, alarm.sound, alarm.vibrate))
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(alarm.label.ifBlank { "Alarm" })
            .setContentText(timeText)
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .setDeleteIntent(actionIntent(ctx, alarm.id, AlarmScheduler.ACTION_STOP, 2))
            .setTimeoutAfter(5 * 60 * 1000L)
            .setAutoCancel(true)
        if (canSnooze) {
            builder.addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(ctx, R.drawable.ic_notif),
                    "Snooze",
                    actionIntent(ctx, alarm.id, AlarmScheduler.ACTION_SNOOZE, 1),
                ).build()
            )
        }
        builder.addAction(
            Notification.Action.Builder(
                Icon.createWithResource(ctx, R.drawable.ic_notif),
                "Stop",
                actionIntent(ctx, alarm.id, AlarmScheduler.ACTION_STOP, 2),
            ).build()
        )
        finish(builder.build(), ctx, alarm.id)
    }
}
