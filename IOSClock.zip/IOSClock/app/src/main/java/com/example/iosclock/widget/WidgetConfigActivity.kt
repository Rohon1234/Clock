package com.example.iosclock.widget

import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.iosclock.ui.CardBg2
import com.example.iosclock.ui.IOSClockTheme
import com.example.iosclock.ui.Subtle
import com.example.iosclock.ui.cityName
import com.example.iosclock.ui.regionName
import java.time.ZoneId

/** Shown when a clock widget is added: pick which city the widget should show. */
class WidgetConfigActivity : ComponentActivity() {
    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID,
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        enableEdgeToEdge()
        setContent { IOSClockTheme { CityPicker(onPick = { save(it) }) } }
    }

    private fun save(zone: String) {
        SecondsWidgets.setZone(this, widgetId, zone)
        SecondsWidgets.refresh(this)
        WeatherRepo.refreshAsync(applicationContext, null)
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        finish()
    }
}

private val pickerZones: List<String> by lazy {
    ZoneId.getAvailableZoneIds()
        .filter { it.contains('/') && !it.startsWith("Etc/") && !it.startsWith("SystemV/") }
        .sorted()
}

@Composable
private fun CityPicker(onPick: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    val entries = remember(query) {
        val q = query.trim().replace(' ', '_')
        val found = if (q.isEmpty()) pickerZones else pickerZones.filter { it.contains(q, ignoreCase = true) }
        (if (q.isEmpty()) listOf("") else emptyList()) + found   // "" = this phone's own time
    }
    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .systemBarsPadding()
            .padding(horizontal = 16.dp),
    ) {
        Text(
            "Choose a City",
            color = Color.White,
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 16.dp),
        )
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            placeholder = { Text("Search") },
            modifier = Modifier.fillMaxWidth(),
        )
        LazyColumn(Modifier.fillMaxSize().padding(top = 8.dp)) {
            items(entries, key = { it }) { id ->
                val title = if (id.isEmpty()) "Local time" else cityName(id)
                val sub = if (id.isEmpty()) "This phone" else regionName(id)
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onPick(if (id.isEmpty()) ZoneId.systemDefault().id else id) }
                        .padding(vertical = 12.dp),
                ) {
                    Text(title, color = Color.White, fontSize = 18.sp)
                    Text(sub, color = Subtle, fontSize = 13.sp)
                }
                HorizontalDivider(color = CardBg2)
            }
        }
    }
}
