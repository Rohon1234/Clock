package com.example.iosclock.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.iosclock.AlarmRoute
import com.example.iosclock.ClockViewModel
import com.example.iosclock.alarm.Sounds
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.abs

private fun snoozeText(min: Int, times: Int): String = when {
    times <= 0 -> "Off"
    times == 1 -> "$min min, 1 time"
    else -> "$min min, $times times"
}

@Composable
fun AlarmEditScreen(vm: ClockViewModel) {
    val ctx = LocalContext.current
    val d = vm.draft
    if (d == null) {
        LaunchedEffect(Unit) { vm.alarmRoute = AlarmRoute.LIST }
        return
    }
    var showRepeat by remember { mutableStateOf(false) }
    var showLabel by remember { mutableStateOf(false) }
    val soundLabel = remember(d.sound) { Sounds.label(ctx, d.sound) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { vm.alarmBack() }) {
                Icon(Icons.Filled.Close, contentDescription = "Close", tint = Color.Black)
            }
            Text(
                if (vm.draftIsNew) "Add Alarm" else "Edit Alarm",
                color = Color.Black,
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f).padding(start = 8.dp),
            )
            IconButton(onClick = { vm.commitDraft() }) {
                Icon(Icons.Filled.Check, contentDescription = "Save", tint = Color.Black)
            }
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            TimeWheels(d.hour, d.minute) { h, m -> vm.draft = vm.draft?.copy(hour = h, minute = m) }
            Spacer(Modifier.height(8.dp))
            OptionRow("Repeat", repeatText(d.days)) { showRepeat = true }
            SwitchRow("Delete this Alarm after Ringing", d.deleteAfterRinging) {
                vm.draft = vm.draft?.copy(deleteAfterRinging = it)
            }
            OptionRow("Alarm Sound", soundLabel) { vm.alarmRoute = AlarmRoute.SOUND }
            OptionRow("Label", d.label) { showLabel = true }
            OptionRow("Snooze", snoozeText(d.snoozeMinutes, d.snoozeTimes)) { vm.alarmRoute = AlarmRoute.SNOOZE }
            SwitchRow("Vibrate while Ringing", d.vibrate) { vm.draft = vm.draft?.copy(vibrate = it) }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showRepeat) {
        RepeatSheet(
            initial = d.days,
            onDismiss = { showRepeat = false },
            onDone = {
                vm.draft = vm.draft?.copy(days = it)
                showRepeat = false
            },
        )
    }
    if (showLabel) {
        LabelDialog(
            initial = d.label,
            onDismiss = { showLabel = false },
            onDone = {
                vm.draft = vm.draft?.copy(label = it)
                showLabel = false
            },
        )
    }
}

// ---------------------------------------------------------------- rows

@Composable
fun OptionRow(title: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, color = Color.Black, fontSize = 17.sp, modifier = Modifier.weight(1f))
        if (value.isNotEmpty()) {
            Text(value, color = AlarmColors.Gray, fontSize = 15.sp, modifier = Modifier.padding(start = 12.dp))
        }
        Icon(
            Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = AlarmColors.Gray,
            modifier = Modifier.padding(start = 4.dp),
        )
    }
}

@Composable
fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(horizontal = 24.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, color = Color.Black, fontSize = 17.sp, modifier = Modifier.weight(1f).padding(end = 12.dp))
        Switch(checked = checked, onCheckedChange = onChange, colors = alarmSwitchColors())
    }
}

// ---------------------------------------------------------------- time wheels

@Composable
private fun TimeWheels(hour: Int, minute: Int, onChange: (Int, Int) -> Unit) {
    var h12 by remember { mutableIntStateOf(hour12(hour)) }
    var min by remember { mutableIntStateOf(minute) }
    var pm by remember { mutableStateOf(hour >= 12) }

    fun push() = onChange((h12 % 12) + (if (pm) 12 else 0), min)

    val hours = remember { (1..12).map { it.toString() } }
    val minutes = remember { (0..59).map { it.toString().padStart(2, '0') } }
    val periods = remember { listOf("AM", "PM") }

    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        WheelPicker(hours, h12 - 1, loop = true) { h12 = it + 1; push() }
        Text(":", color = Color.Black, fontSize = 34.sp, modifier = Modifier.padding(horizontal = 2.dp))
        WheelPicker(minutes, min, loop = true) { min = it; push() }
        Spacer(Modifier.width(16.dp))
        WheelPicker(periods, if (pm) 1 else 0, loop = false) { pm = it == 1; push() }
    }
}

/**
 * Vertical snapping wheel with five visible rows. The row in the middle is the selected one:
 * black and big; rows further away get smaller and lighter.
 */
@Composable
fun WheelPicker(
    items: List<String>,
    selectedIndex: Int,
    loop: Boolean,
    itemH: androidx.compose.ui.unit.Dp = 52.dp,
    width: androidx.compose.ui.unit.Dp = 84.dp,
    onSelected: (Int) -> Unit,
) {
    val n = items.size
    val k = itemH.value / 52f
    val itemHPx = with(LocalDensity.current) { itemH.toPx() }
    val total = if (loop) n * 400 else n + 4
    val start = if (loop) n * 200 + selectedIndex - 2 else selectedIndex
    val state = rememberLazyListState(initialFirstVisibleItemIndex = start)
    val fling = rememberSnapFlingBehavior(state)

    LaunchedEffect(state) {
        snapshotFlow { state.isScrollInProgress to state.firstVisibleItemIndex }
            .collect { (scrolling, first) ->
                if (!scrolling) {
                    val v = if (loop) (first + 2) % n else first.coerceIn(0, n - 1)
                    onSelected(v)
                }
            }
    }

    val center by remember {
        derivedStateOf { state.firstVisibleItemIndex + state.firstVisibleItemScrollOffset / itemHPx + 2f }
    }

    Box(Modifier.width(width).height(itemH * 5)) {
        LazyColumn(state = state, flingBehavior = fling, modifier = Modifier.fillMaxSize()) {
            items(total) { index ->
                val dist = abs(index - center)
                val t = (1f - dist).coerceIn(0f, 1f)
                val label = if (loop) items[index % n] else (items.getOrNull(index - 2) ?: "")
                Box(Modifier.fillMaxWidth().height(itemH), contentAlignment = Alignment.Center) {
                    Text(
                        label,
                        color = lerp(AlarmColors.LightGray, Color.Black, t),
                        fontSize = ((26f + 10f * t) * k).sp,
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------- repeat sheet and label dialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RepeatSheet(initial: Set<Int>, onDismiss: () -> Unit, onDone: (Set<Int>) -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    var sel by remember { mutableStateOf(initial) }

    fun close(after: () -> Unit) {
        scope.launch { sheetState.hide() }.invokeOnCompletion { after() }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color.White,
        scrimColor = Color(0x66000000),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = null,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 16.dp),
        ) {
            Text("Repeat", color = Color.Black, fontSize = 22.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(bottom = 8.dp))
            weekOrder.forEach { day ->
                val on = day in sel
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { sel = if (on) sel - day else sel + day }
                        .padding(vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        DayOfWeek.of(day).getDisplayName(TextStyle.FULL, Locale.ENGLISH),
                        color = Color.Black,
                        fontSize = 17.sp,
                        modifier = Modifier.weight(1f),
                    )
                    Checkbox(checked = on, onCheckedChange = null, colors = alarmCheckboxColors())
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                TextButton(onClick = { close { onDismiss() } }) {
                    Text("Cancel", color = Color(0xFF3C3C43), fontSize = 17.sp)
                }
                TextButton(onClick = { close { onDone(sel) } }) {
                    Text("Done", color = AlarmColors.Blue, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
fun LabelDialog(initial: String, onDismiss: () -> Unit, onDone: (String) -> Unit, title: String = "Label") {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        title = { Text(title, color = Color.Black) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(40) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = { TextButton(onClick = { onDone(text.trim()) }) { Text("OK", color = AlarmColors.Blue) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = AlarmColors.Blue) } },
    )
}
