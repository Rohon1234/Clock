package com.example.iosclock.alarm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** days: java.time.DayOfWeek values (Monday = 1 .. Sunday = 7). Empty set = one-time alarm. */
data class Alarm(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val label: String = "",
    val enabled: Boolean = true,
    val days: Set<Int> = emptySet(),
)

object AlarmStore {
    private const val PREFS = "clock_prefs"
    private const val KEY = "alarms"

    fun load(ctx: Context): List<Alarm> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val d = o.getJSONArray("days")
                Alarm(
                    id = o.getInt("id"),
                    hour = o.getInt("hour"),
                    minute = o.getInt("minute"),
                    label = o.optString("label", ""),
                    enabled = o.optBoolean("enabled", true),
                    days = (0 until d.length()).map { d.getInt(it) }.toSet(),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, list: List<Alarm>) {
        val arr = JSONArray()
        list.forEach { a ->
            arr.put(
                JSONObject()
                    .put("id", a.id)
                    .put("hour", a.hour)
                    .put("minute", a.minute)
                    .put("label", a.label)
                    .put("enabled", a.enabled)
                    .put("days", JSONArray(a.days.toList()))
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun update(ctx: Context, alarm: Alarm) {
        save(ctx, load(ctx).map { if (it.id == alarm.id) alarm else it })
    }
}

object ZoneStore {
    private const val PREFS = "clock_prefs"
    private const val KEY = "zones"
    private val defaults = listOf(
        "Asia/Dhaka", "America/New_York", "Europe/London", "Asia/Tokyo", "Australia/Sydney",
    )

    fun load(ctx: Context): List<String> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return defaults
        return raw.split(",").filter { it.isNotBlank() }
    }

    fun save(ctx: Context, zones: List<String>) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY, zones.joinToString(",")).apply()
    }
}
