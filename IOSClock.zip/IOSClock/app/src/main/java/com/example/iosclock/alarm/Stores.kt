package com.example.iosclock.alarm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

const val SOUND_DEFAULT = "default"
const val SOUND_SILENT = "silent"

/** days: java.time.DayOfWeek values (Monday = 1 .. Sunday = 7). Empty set = one-time alarm. */
data class Alarm(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val label: String = "",
    val enabled: Boolean = true,
    val days: Set<Int> = emptySet(),
    val deleteAfterRinging: Boolean = false,
    val sound: String = SOUND_DEFAULT,
    val vibrate: Boolean = true,
    val snoozeMinutes: Int = 10,
    val snoozeTimes: Int = 3,
)

object AlarmStore {
    private const val PREFS = "clock_prefs"
    private const val KEY = "alarms"

    fun load(ctx: Context): List<Alarm> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val d = o.getJSONArray("days")
                Alarm(
                    id = o.getInt("id"),
                    hour = o.getInt("hour"),
                    minute = o.getInt("minute"),
                    label = o.optString("label", ""),
                    enabled = o.optBoolean("enabled", true),
                    days = (0 until d.length()).map { d.getInt(it) }.toSet(),
                    deleteAfterRinging = o.optBoolean("del", false),
                    sound = o.optString("sound", SOUND_DEFAULT),
                    vibrate = o.optBoolean("vib", true),
                    snoozeMinutes = o.optInt("snzMin", 10),
                    snoozeTimes = o.optInt("snzTimes", 3),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, list: List<Alarm>) {
        val arr = JSONArray()
        list.forEach { a ->
            arr.put(
                JSONObject()
                    .put("id", a.id)
                    .put("hour", a.hour)
                    .put("minute", a.minute)
                    .put("label", a.label)
                    .put("enabled", a.enabled)
                    .put("days", JSONArray(a.days.toList()))
                    .put("del", a.deleteAfterRinging)
                    .put("sound", a.sound)
                    .put("vib", a.vibrate)
                    .put("snzMin", a.snoozeMinutes)
                    .put("snzTimes", a.snoozeTimes)
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun update(ctx: Context, alarm: Alarm) {
        save(ctx, load(ctx).map { if (it.id == alarm.id) alarm else it })
    }

    fun remove(ctx: Context, id: Int) {
        save(ctx, load(ctx).filter { it.id != id })
    }
}

object ZoneStore {
    private const val PREFS = "clock_prefs"
    private const val KEY = "zones"
    private val defaults = listOf(
        "Asia/Dhaka", "America/New_York", "Europe/London", "Asia/Tokyo", "Australia/Sydney",
    )

    fun load(ctx: Context): List<String> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return defaults
        return raw.split(",").filter { it.isNotBlank() }
    }

    fun save(ctx: Context, zones: List<String>) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY, zones.joinToString(",")).apply()
    }
}

/** Small on/off settings shown on the Alarm Settings page. */
object SettingsStore {
    private const val PREFS = "clock_prefs"

    fun get(ctx: Context, key: String, default: Boolean): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(key, default)

    fun set(ctx: Context, key: String, value: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(key, value).apply()
    }
}
